package com.anubhav.aakash.ui.forecast

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material.icons.filled.WbTwilight
import androidx.compose.material.icons.outlined.WaterDrop
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.anubhav.aakash.data.model.computeDayPhase
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.anubhav.aakash.data.model.DailyItem
import com.anubhav.aakash.data.model.WeatherKind
import com.anubhav.aakash.ui.atmosphere.AtmosphereBackground
import com.anubhav.aakash.ui.common.UnitUtils
import com.anubhav.aakash.ui.common.rememberHapticHelper
import com.anubhav.aakash.ui.home.HomeUiState
import com.anubhav.aakash.ui.home.HomeViewModel
import com.anubhav.aakash.ui.home.getWeatherIcon
import com.anubhav.aakash.ui.theme.CyanAccent
import com.anubhav.aakash.ui.theme.GoldAccent
import com.anubhav.aakash.ui.theme.TextPrimary
import com.anubhav.aakash.ui.theme.TextSecondary
import com.anubhav.aakash.ui.theme.glassCard

@Composable
fun ForecastScreen(
    homeViewModel: HomeViewModel,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val uiState by homeViewModel.uiState.collectAsState()
    val tempUnit by homeViewModel.tempUnit.collectAsState()
    val animationsEnabled by homeViewModel.animationsEnabled.collectAsState()
    val hapticsEnabled by homeViewModel.hapticsEnabled.collectAsState()
    val hapticHelper = rememberHapticHelper()

    var currentTimeMillis by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (isActive) {
            delay(60_000L)
            currentTimeMillis = System.currentTimeMillis()
        }
    }

    val weatherData = (uiState as? HomeUiState.Success)?.data
    val currentKind = weatherData?.current?.weatherKind ?: WeatherKind.CLEAR
    val dailyList = weatherData?.daily ?: emptyList()

    val dayPhase = remember(currentTimeMillis, weatherData) {
        computeDayPhase(
            nowMillis = currentTimeMillis,
            sunriseMillis = weatherData?.sunriseEpochMillis,
            sunsetMillis = weatherData?.sunsetEpochMillis,
            fallbackIsNight = weatherData?.current?.isNight ?: false
        )
    }

    var expandedIndex by remember { mutableStateOf(0) } // Today expanded by default

    AtmosphereBackground(
        kind = currentKind,
        phase = dayPhase,
        animationsEnabled = animationsEnabled,
        modifier = modifier
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
        ) {
            // Header Row: Back Chevron + Title
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = {
                        hapticHelper.triggerClick(hapticsEnabled)
                        onBack()
                    },
                    modifier = Modifier.testTag("forecast_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = TextPrimary
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Text(
                    text = "7-Day Forecast",
                    style = MaterialTheme.typography.titleLarge,
                    color = TextPrimary
                )
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 100.dp)
            ) {
                itemsIndexed(dailyList) { index, day ->
                    val isExpanded = expandedIndex == index

                    ExpandableDayCard(
                        day = day,
                        tempUnit = tempUnit,
                        isExpanded = isExpanded,
                        onToggle = {
                            hapticHelper.triggerTick(hapticsEnabled)
                            expandedIndex = if (isExpanded) -1 else index
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun ExpandableDayCard(
    day: DailyItem,
    tempUnit: String,
    isExpanded: Boolean,
    onToggle: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("forecast_day_card_${day.date}")
            .glassCard(RoundedCornerShape(20.dp))
            .animateContentSize()
            .clickable { onToggle() }
            .padding(16.dp)
    ) {
        // Main Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Left: Day Name + Date
            Column(modifier = Modifier.width(80.dp)) {
                Text(
                    text = day.dayName,
                    style = MaterialTheme.typography.titleMedium,
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = day.date.takeLast(5),
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary
                )
            }

            // Center: Icon + Condition
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.width(100.dp)
            ) {
                Icon(
                    imageVector = getWeatherIcon(day.weatherKind),
                    contentDescription = day.weatherKind.description,
                    tint = TextPrimary,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = day.weatherKind.description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary,
                    maxLines = 1
                )
            }

            // Right: Precip % + Temp Range
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (day.precipProb > 0) {
                    Text(
                        text = "${day.precipProb}%",
                        fontSize = 11.sp,
                        color = CyanAccent,
                        modifier = Modifier.padding(end = 8.dp)
                    )
                }

                Text(
                    text = "${UnitUtils.formatTemp(day.tempMin, tempUnit)} / ${UnitUtils.formatTemp(day.tempMax, tempUnit)}",
                    style = MaterialTheme.typography.labelLarge,
                    color = TextPrimary
                )

                Icon(
                    imageVector = if (isExpanded) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                    contentDescription = if (isExpanded) "Collapse" else "Expand",
                    tint = TextSecondary,
                    modifier = Modifier
                        .padding(start = 4.dp)
                        .size(20.dp)
                )
            }
        }

        // Expanded Details Row (Sunrise, Sunset, Humidity)
        if (isExpanded) {
            Spacer(modifier = Modifier.height(16.dp))

            // Temp Gradient Range Bar
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(CyanAccent, GoldAccent)
                        )
                    )
            )

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                DetailColumn(
                    icon = Icons.Filled.WbSunny,
                    label = "Sunrise",
                    value = day.sunrise
                )

                DetailColumn(
                    icon = Icons.Filled.WbTwilight,
                    label = "Sunset",
                    value = day.sunset
                )

                DetailColumn(
                    icon = Icons.Outlined.WaterDrop,
                    label = "Humidity",
                    value = "${day.humidity}%"
                )
            }
        }
    }
}

@Composable
private fun DetailColumn(
    icon: ImageVector,
    label: String,
    value: String
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = CyanAccent,
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = TextSecondary
        )
        Text(
            text = value,
            style = MaterialTheme.typography.labelMedium,
            color = TextPrimary,
            fontWeight = FontWeight.SemiBold
        )
    }
}
