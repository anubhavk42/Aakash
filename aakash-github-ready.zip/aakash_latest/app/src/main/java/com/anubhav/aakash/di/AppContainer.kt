package com.anubhav.aakash.di

import android.content.Context
import com.anubhav.aakash.data.api.OpenMeteoService
import com.anubhav.aakash.data.api.RainViewerService
import com.anubhav.aakash.data.repo.RadarRepository
import com.anubhav.aakash.data.repo.WeatherRepository
import com.anubhav.aakash.data.repo.dataStore
import org.maplibre.android.MapLibre
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

class AppContainer(private val context: Context) {

    init {
        try {
            MapLibre.getInstance(context)
        } catch (_: Exception) {}
    }

    val gson: Gson by lazy {
        GsonBuilder()
            .setLenient()
            .create()
    }

    private val okHttpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .addInterceptor(HttpLoggingInterceptor().apply {
                level = HttpLoggingInterceptor.Level.BODY
            })
            .build()
    }

    private val retrofit: Retrofit by lazy {
        Retrofit.Builder()
            .baseUrl("https://api.open-meteo.com/")
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create(gson))
            .build()
    }

    private val rainViewerRetrofit: Retrofit by lazy {
        Retrofit.Builder()
            .baseUrl("https://api.rainviewer.com/")
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create(gson))
            .build()
    }

    val openMeteoService: OpenMeteoService by lazy {
        retrofit.create(OpenMeteoService::class.java)
    }

    val rainViewerService: RainViewerService by lazy {
        rainViewerRetrofit.create(RainViewerService::class.java)
    }

    val weatherRepository: WeatherRepository by lazy {
        WeatherRepository(
            api = openMeteoService,
            dataStore = context.dataStore,
            gson = gson
        )
    }

    val radarRepository: RadarRepository by lazy {
        RadarRepository(
            api = rainViewerService,
            openMeteoApi = openMeteoService
        )
    }
}
