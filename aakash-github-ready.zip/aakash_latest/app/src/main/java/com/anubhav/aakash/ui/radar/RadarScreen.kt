package com.anubhav.aakash.ui.radar

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Grain
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Thunderstorm
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.anubhav.aakash.R
import com.anubhav.aakash.data.model.WeatherKind
import com.anubhav.aakash.ui.common.HapticHelper
import com.anubhav.aakash.ui.common.rememberHapticHelper
import com.anubhav.aakash.ui.theme.CyanAccent
import com.anubhav.aakash.ui.theme.GlassBackground
import com.anubhav.aakash.ui.theme.GlassBorder
import com.anubhav.aakash.ui.theme.IndigoBaseDark
import com.anubhav.aakash.ui.theme.TextPrimary
import com.anubhav.aakash.ui.theme.TextSecondary
import com.anubhav.aakash.ui.theme.glassCard
import kotlinx.coroutines.delay
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.camera.CameraUpdateFactory
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.MapView
import org.maplibre.android.maps.Style
import org.maplibre.android.style.layers.PropertyFactory
import org.maplibre.android.style.layers.RasterLayer
import org.maplibre.android.style.sources.RasterSource
import org.maplibre.android.style.sources.TileSet
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private const val CARTO_DARK_STYLE_JSON = """
{
  "version": 8,
  "sources": {
    "carto-dark": {
      "type": "raster",
      "tiles": [
        "https://basemaps.cartocdn.com/dark_all/{z}/{x}/{y}@2x.png"
      ],
      "tileSize": 256,
      "attribution": "Radar © RainViewer · Map © CARTO © OpenStreetMap contributors"
    }
  },
  "layers": [
    {
      "id": "carto-dark-layer",
      "type": "raster",
      "source": "carto-dark",
      "minzoom": 0,
      "maxzoom": 20
    }
  ]
}
"""

@Composable
fun RadarScreen(
    viewModel: RadarViewModel,
    hapticHelper: HapticHelper = rememberHapticHelper(),
    hapticsEnabled: Boolean = true,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    var mapLibreMap by remember { mutableStateOf<MapLibreMap?>(null) }
    var mapViewRef by remember { mutableStateOf<MapView?>(null) }
    var isStyleLoaded by remember { mutableStateOf(false) }
    var markerScreenPoint by remember { mutableStateOf<android.graphics.PointF?>(null) }

    fun updateMarkerPosition(map: MapLibreMap) {
        try {
            val point = map.projection.toScreenLocation(LatLng(uiState.cityLat, uiState.cityLon))
            markerScreenPoint = point
        } catch (_: Exception) {}
    }

    // Pulsing dot animation for location marker
    val transition = rememberInfiniteTransition(label = "pulse_marker")
    val pulseRadius = transition.animateFloat(
        initialValue = 12.dp.value,
        targetValue = 28.dp.value,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulse"
    )

    // Center map camera on city when city changes or map becomes ready
    LaunchedEffect(mapLibreMap, isStyleLoaded, uiState.cityLat, uiState.cityLon) {
        val map = mapLibreMap
        if (map != null && isStyleLoaded) {
            val cameraPos = CameraPosition.Builder()
                .target(LatLng(uiState.cityLat, uiState.cityLon))
                .zoom(6.0)
                .build()
            map.moveCamera(CameraUpdateFactory.newCameraPosition(cameraPos))
            updateMarkerPosition(map)
        }
    }

    // Update tile URL on MapLibre map when frame or host changes
    LaunchedEffect(uiState.currentTileUrl, isStyleLoaded, mapLibreMap) {
        val map = mapLibreMap
        if (map != null && isStyleLoaded) {
            updateRadarLayer(map, uiState.currentTileUrl)
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(IndigoBaseDark)
    ) {
        // 1. MapLibre Android MapView with Carto Dark Matter raster style
        AndroidView(
            factory = { ctx ->
                MapView(ctx).apply {
                    onCreate(null)
                    onStart()
                    onResume()
                    mapViewRef = this
                    getMapAsync { map ->
                        mapLibreMap = map
                        map.setMaxZoomPreference(7.0)
                        map.setMinZoomPreference(2.0)
                        map.uiSettings.isAttributionEnabled = false
                        map.uiSettings.isLogoEnabled = false

                        map.addOnCameraMoveListener {
                            updateMarkerPosition(map)
                        }
                        map.addOnCameraMoveCancelListener {
                            updateMarkerPosition(map)
                        }
                        map.addOnCameraIdleListener {
                            updateMarkerPosition(map)
                        }

                        map.setStyle(Style.Builder().fromJson(CARTO_DARK_STYLE_JSON)) { style ->
                            isStyleLoaded = true
                            updateRadarLayer(map, uiState.currentTileUrl)
                            updateMarkerPosition(map)
                        }
                    }
                }
            },
            modifier = Modifier.fillMaxSize(),
            onRelease = { mapView ->
                try {
                    mapView.onPause()
                    mapView.onStop()
                    mapView.onDestroy()
                } catch (_: Exception) {}
                mapViewRef = null
            }
        )

        // Lifecycle forwarding for MapView
        DisposableEffect(lifecycleOwner) {
            val observer = LifecycleEventObserver { _, event ->
                // Forward lifecycle to MapView — required by MapLibre to
                // manage its GL surface (prevents black map on resume + leaks)
                when (event) {
                    Lifecycle.Event.ON_START -> mapViewRef?.onStart()
                    Lifecycle.Event.ON_RESUME -> mapViewRef?.onResume()
                    Lifecycle.Event.ON_PAUSE -> mapViewRef?.onPause()
                    Lifecycle.Event.ON_STOP -> mapViewRef?.onStop()
                    Lifecycle.Event.ON_DESTROY -> {
                        mapLibreMap = null
                        mapViewRef = null
                    }
                    else -> {}
                }
            }
            lifecycleOwner.lifecycle.addObserver(observer)
            onDispose {
                lifecycleOwner.lifecycle.removeObserver(observer)
            }
        }

        // 2. Apple-Style Map-Anchored Location Marker
        val density = LocalDensity.current
        markerScreenPoint?.let { point ->
            val xDp = with(density) { point.x.toDp() }
            val yDp = with(density) { point.y.toDp() }

            Box(
                modifier = Modifier
                    .offset {
                        IntOffset(
                            xDp.roundToPx() - with(density) { 48.dp.roundToPx() },
                            yDp.roundToPx() - with(density) { 46.dp.roundToPx() }
                        )
                    }
            ) {
                AppleStyleLocationMarker(
                    temperature = "${uiState.currentTemp}°",
                    weatherKind = uiState.weatherKind,
                    pulseRadius = pulseRadius.value
                )
            }
        }

        // 3. Overlay UI
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .padding(bottom = 90.dp)
        ) {
            // Top Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Filled.Radar,
                    contentDescription = "Radar",
                    tint = CyanAccent,
                    modifier = Modifier.size(28.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = stringResource(R.string.radar_title),
                        style = MaterialTheme.typography.titleLarge,
                        color = TextPrimary
                    )
                    Text(
                        text = uiState.cityName,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }

            // Filter Chips & Intensity Legend Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                // Filter Chips Row
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(CyanAccent)
                            .padding(horizontal = 14.dp, vertical = 7.dp)
                    ) {
                        Text(
                            text = stringResource(R.string.radar_chip_precipitation),
                            color = Color.Black,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    ChipWithBadge(label = stringResource(R.string.radar_chip_temperature))
                    ChipWithBadge(label = stringResource(R.string.radar_chip_wind))
                }

                // Intensity Legend Card
                IntensityLegend(
                    isExpanded = uiState.isLegendExpanded,
                    onToggle = {
                        hapticHelper.triggerTick(hapticsEnabled)
                        viewModel.toggleLegendExpanded()
                    },
                    onAutoCollapse = {
                        viewModel.setLegendExpanded(false)
                    }
                )
            }

            Spacer(modifier = Modifier.weight(1f))

            // Bottom Glass Card with Scrubber, Nowcast Strip, and Attribution
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .glassCard(RoundedCornerShape(20.dp))
                    .padding(16.dp)
            ) {
                when {
                    uiState.isLoading -> {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(24.dp),
                                color = CyanAccent,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = stringResource(R.string.radar_loading),
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextSecondary
                            )
                        }
                    }

                    uiState.isError -> {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = uiState.errorMessage ?: "Failed to load radar",
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextSecondary,
                                modifier = Modifier.weight(1f)
                            )
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(CyanAccent)
                                    .clickable {
                                        hapticHelper.triggerTick(hapticsEnabled)
                                        viewModel.loadCatalog(forceRefresh = true)
                                    }
                                    .padding(horizontal = 12.dp, vertical = 8.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Filled.Refresh,
                                        contentDescription = "Retry",
                                        tint = Color.Black,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = stringResource(R.string.radar_error_retry),
                                        color = Color.Black,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }

                    uiState.frames.isEmpty() -> {
                        Text(
                            text = stringResource(R.string.radar_unavailable),
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary,
                            modifier = Modifier.align(Alignment.Center)
                        )
                    }

                    else -> {
                        Column {
                            // Scrubber Header: Segmented Pill on Left, Selected Time on Right
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(GlassBackground)
                                        .border(1.dp, GlassBorder, RoundedCornerShape(8.dp))
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = stringResource(R.string.radar_past_2h),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = CyanAccent
                                    )
                                }

                                val frameTime = uiState.currentFrame?.time ?: 0L
                                Text(
                                    text = formatFrameTime(frameTime),
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            // Play/Pause & Slider Row
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(CyanAccent.copy(alpha = 0.2f))
                                        .border(1.dp, CyanAccent.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                                        .clickable {
                                            hapticHelper.triggerTick(hapticsEnabled)
                                            viewModel.togglePlayPause()
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = if (uiState.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                                        contentDescription = if (uiState.isPlaying) "Pause" else "Play",
                                        tint = CyanAccent,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.width(10.dp))

                                Slider(
                                    value = uiState.currentFrameIndex.toFloat(),
                                    onValueChange = { newValue ->
                                        val newIdx = newValue.toInt()
                                        if (newIdx != uiState.currentFrameIndex) {
                                            hapticHelper.triggerTick(hapticsEnabled)
                                            viewModel.seekToFrame(newIdx)
                                        }
                                    },
                                    valueRange = 0f..((uiState.frames.size - 1).coerceAtLeast(1)).toFloat(),
                                    steps = (uiState.frames.size - 2).coerceAtLeast(0),
                                    colors = SliderDefaults.colors(
                                        thumbColor = CyanAccent,
                                        activeTrackColor = CyanAccent,
                                        inactiveTrackColor = Color.White.copy(alpha = 0.2f),
                                        activeTickColor = Color.Transparent,
                                        inactiveTickColor = Color.Transparent
                                    ),
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            // Scrubber Tick Labels Row
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(start = 50.dp, end = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("-2h", fontSize = 10.sp, color = TextSecondary)
                                Text("-1.5h", fontSize = 10.sp, color = TextSecondary)
                                Text("-1h", fontSize = 10.sp, color = TextSecondary)
                                Text("-30m", fontSize = 10.sp, color = TextSecondary)
                                Text(
                                    text = stringResource(R.string.radar_now),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = CyanAccent
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            // Nowcast Strip
                            NowcastStrip(precipitationList = uiState.minutelyPrecipitation)

                            Spacer(modifier = Modifier.height(10.dp))

                            // Attribution Line
                            Text(
                                text = stringResource(R.string.radar_attribution),
                                fontSize = 10.sp,
                                color = Color.White.copy(alpha = 0.40f),
                                modifier = Modifier.align(Alignment.CenterHorizontally)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun IntensityLegend(
    isExpanded: Boolean,
    onToggle: () -> Unit,
    onAutoCollapse: () -> Unit
) {
    LaunchedEffect(isExpanded) {
        if (isExpanded) {
            delay(4000L)
            onAutoCollapse()
        }
    }

    val rampGradient = Brush.verticalGradient(
        colors = listOf(
            Color(0xFFEC407A), // Extreme (Red/Pink)
            Color(0xFFAB47BC), // Heavy (Purple)
            Color(0xFF29B6F6), // Moderate (Blue)
            Color(0xFF80DEEA)  // Light (Light Blue)
        )
    )

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .glassCard(RoundedCornerShape(12.dp))
            .clickable { onToggle() }
            .padding(6.dp)
    ) {
        if (!isExpanded) {
            Box(
                modifier = Modifier
                    .width(10.dp)
                    .height(38.dp)
                    .clip(RoundedCornerShape(5.dp))
                    .background(rampGradient)
            )
        } else {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
            ) {
                Box(
                    modifier = Modifier
                        .width(10.dp)
                        .height(72.dp)
                        .clip(RoundedCornerShape(5.dp))
                        .background(rampGradient)
                )
                Column(
                    modifier = Modifier.height(72.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(stringResource(R.string.radar_legend_extreme), fontSize = 10.sp, color = TextPrimary, fontWeight = FontWeight.Bold)
                    Text(stringResource(R.string.radar_legend_heavy), fontSize = 10.sp, color = TextPrimary)
                    Text(stringResource(R.string.radar_legend_moderate), fontSize = 10.sp, color = TextPrimary)
                    Text(stringResource(R.string.radar_legend_light), fontSize = 10.sp, color = TextPrimary)
                }
            }
        }
    }
}

@Composable
private fun AppleStyleLocationMarker(
    temperature: String,
    weatherKind: WeatherKind,
    pulseRadius: Float
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.width(96.dp)
    ) {
        // Glass circle bubble
        Box(
            modifier = Modifier
                .clip(CircleShape)
                .background(GlassBackground)
                .border(1.5.dp, CyanAccent, CircleShape)
                .padding(horizontal = 8.dp, vertical = 4.dp),
            contentAlignment = Alignment.Center
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Icon(
                    imageVector = weatherKindIcon(weatherKind),
                    contentDescription = null,
                    tint = CyanAccent,
                    modifier = Modifier.size(13.dp)
                )
                Text(
                    text = temperature,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            }
        }

        // Stem
        Box(
            modifier = Modifier
                .width(2.dp)
                .height(8.dp)
                .background(CyanAccent)
        )

        // Dot with pulsing ring behind
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.size(20.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(pulseRadius.dp)
                    .clip(CircleShape)
                    .background(CyanAccent.copy(alpha = 0.35f))
            )
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(CyanAccent)
                    .border(1.dp, Color.White, CircleShape)
            )
        }

        // Label "My Location"
        Text(
            text = stringResource(R.string.radar_my_location),
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            color = TextPrimary
        )
    }
}

@Composable
private fun NowcastStrip(precipitationList: List<Double>) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 8.dp)
    ) {
        Text(
            text = stringResource(R.string.radar_nowcast_title),
            fontSize = 11.sp,
            color = TextSecondary,
            fontWeight = FontWeight.Medium
        )
        Spacer(modifier = Modifier.height(6.dp))

        val maxPrecip = precipitationList.maxOrNull() ?: 0.0
        val hasRain = maxPrecip > 0.001

        if (!hasRain) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.WbSunny,
                    contentDescription = null,
                    tint = CyanAccent,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = stringResource(R.string.radar_nowcast_no_rain),
                    fontSize = 12.sp,
                    color = TextPrimary
                )
            }
        } else {
            val displayList = if (precipitationList.size >= 8) precipitationList.take(8)
            else (precipitationList + List(8 - precipitationList.size) { 0.0 })

            Column {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(32.dp),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.Bottom
                ) {
                    displayList.forEach { valMm ->
                        val barHeightFactor = if (maxPrecip > 0) (valMm / maxPrecip).toFloat() else 0f
                        val barHeight = (barHeightFactor * 26).dp.coerceAtLeast(3.dp)

                        Box(
                            modifier = Modifier
                                .width(14.dp)
                                .height(barHeight)
                                .clip(RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp))
                                .background(if (valMm > 0) CyanAccent else Color.White.copy(alpha = 0.2f))
                        )
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("+15m", fontSize = 9.sp, color = TextSecondary)
                    Text("+30m", fontSize = 9.sp, color = TextSecondary)
                    Text("+1h", fontSize = 9.sp, color = TextSecondary)
                    Text("+1.5h", fontSize = 9.sp, color = TextSecondary)
                    Text("+2h", fontSize = 9.sp, color = TextSecondary)
                }
            }
        }
    }
}

private fun weatherKindIcon(kind: WeatherKind): ImageVector {
    return when (kind) {
        WeatherKind.CLEAR -> Icons.Filled.WbSunny
        WeatherKind.CLOUDY, WeatherKind.OVERCAST -> Icons.Filled.Cloud
        WeatherKind.DRIZZLE -> Icons.Filled.Grain
        WeatherKind.RAIN -> Icons.Filled.WaterDrop
        WeatherKind.STORM -> Icons.Filled.Thunderstorm
        WeatherKind.SNOW -> Icons.Filled.AcUnit
        WeatherKind.FOG -> Icons.Filled.Cloud
    }
}

private fun updateRadarLayer(map: MapLibreMap, tileUrl: String?) {
    val style = map.style ?: return
    val sourceId = "rainviewer-radar-source"
    val layerId = "rainviewer-radar-layer"

    if (tileUrl.isNullOrBlank()) {
        try {
            if (style.getLayer(layerId) != null) style.removeLayer(layerId)
            if (style.getSource(sourceId) != null) style.removeSource(sourceId)
        } catch (_: Exception) {}
        return
    }

    try {
        val tileSet = TileSet("2.1.0", tileUrl).apply {
            minZoom = 0f
            maxZoom = 7f
        }
        val newSource = RasterSource(sourceId, tileSet, 512)

        if (style.getLayer(layerId) != null) style.removeLayer(layerId)
        if (style.getSource(sourceId) != null) style.removeSource(sourceId)

        style.addSource(newSource)
        val newLayer = RasterLayer(layerId, sourceId).apply {
            setProperties(PropertyFactory.rasterOpacity(0.75f))
        }
        style.addLayer(newLayer)
    } catch (_: Exception) {
        // Graceful error handling
    }
}

private fun formatFrameTime(timestampSec: Long): String {
    if (timestampSec <= 0L) return "--:--"
    return try {
        val sdf = SimpleDateFormat("HH:mm", Locale.getDefault())
        sdf.format(Date(timestampSec * 1000L))
    } catch (_: Exception) {
        "--:--"
    }
}

@Composable
private fun ChipWithBadge(label: String) {
    Row(
        modifier = Modifier
            .clip(CircleShape)
            .background(GlassBackground)
            .border(1.dp, GlassBorder, CircleShape)
            .padding(horizontal = 10.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            color = TextSecondary,
            fontSize = 12.sp
        )
        Spacer(modifier = Modifier.width(4.dp))
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(6.dp))
                .background(Color.White.copy(alpha = 0.2f))
                .padding(horizontal = 4.dp, vertical = 2.dp)
        ) {
            Text(
                text = stringResource(R.string.radar_chip_soon),
                color = TextSecondary,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
