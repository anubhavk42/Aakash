package com.anubhav.aakash.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.anubhav.aakash.data.model.GeoPlace
import com.anubhav.aakash.data.model.WeatherData
import com.anubhav.aakash.data.repo.WeatherRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

sealed interface HomeUiState {
    data object Idle : HomeUiState
    data object Loading : HomeUiState
    data class Success(
        val data: WeatherData,
        val isOffline: Boolean,
        val lastUpdatedText: String
    ) : HomeUiState
    data class Error(val message: String) : HomeUiState
}

class HomeViewModel(
    private val repository: WeatherRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<HomeUiState>(HomeUiState.Idle)
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    private val _isRefreshing = MutableStateFlow(false)
    val isRefreshing: StateFlow<Boolean> = _isRefreshing.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _searchResults = MutableStateFlow<List<GeoPlace>>(emptyList())
    val searchResults: StateFlow<List<GeoPlace>> = _searchResults.asStateFlow()

    private val _isSearching = MutableStateFlow(false)
    val isSearching: StateFlow<Boolean> = _isSearching.asStateFlow()

    val tempUnit = repository.tempUnitFlow.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        "C"
    )

    val speedUnit = repository.speedUnitFlow.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        "kmh"
    )

    val animationsEnabled = repository.animationsFlow.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        true
    )

    val hapticsEnabled = repository.hapticsFlow.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        true
    )

    val savedCities = repository.savedCitiesFlow.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    val lastSelectedCity = repository.lastSelectedCityFlow.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        WeatherRepository.DEFAULT_CITY
    )

    private var currentCity: GeoPlace = WeatherRepository.DEFAULT_CITY
    private var searchJob: Job? = null

    init {
        viewModelScope.launch {
            repository.lastSelectedCityFlow.collect { city ->
                currentCity = city
                if (_uiState.value is HomeUiState.Idle) {
                    loadWeather(city)
                }
            }
        }
    }

    fun checkAndSilentRefresh() {
        val currentState = _uiState.value
        if (currentState is HomeUiState.Success) {
            val ageMs = System.currentTimeMillis() - currentState.data.lastUpdatedEpoch
            if (ageMs > 15 * 60 * 1000L) {
                viewModelScope.launch {
                    val result = repository.fetchWeather(currentCity)
                    result.onSuccess { data ->
                        val updatedStr = formatLastUpdated(data.lastUpdatedEpoch)
                        _uiState.value = HomeUiState.Success(data, isOffline = false, lastUpdatedText = updatedStr)
                    }
                }
            }
        }
    }

    fun loadWeather(city: GeoPlace? = null) {
        val targetCity = city ?: currentCity
        currentCity = targetCity

        viewModelScope.launch {
            // Delay 300ms before showing shimmer if loading is fast
            val delayJob = launch {
                delay(300)
                if (_uiState.value is HomeUiState.Idle || _uiState.value is HomeUiState.Error) {
                    _uiState.value = HomeUiState.Loading
                }
            }

            val result = repository.fetchWeather(targetCity)
            delayJob.cancel()

            result.fold(
                onSuccess = { data ->
                    val isOffline = false
                    val updatedStr = formatLastUpdated(data.lastUpdatedEpoch)
                    _uiState.value = HomeUiState.Success(data, isOffline, updatedStr)
                },
                onFailure = { err ->
                    // Try getting cached data
                    val cached = repository.getCachedWeatherData()
                    if (cached != null) {
                        val updatedStr = formatLastUpdated(cached.lastUpdatedEpoch)
                        _uiState.value = HomeUiState.Success(cached, isOffline = true, lastUpdatedText = updatedStr)
                    } else {
                        _uiState.value = HomeUiState.Error(
                            err.localizedMessage ?: "Unable to load weather. Check internet connection."
                        )
                    }
                }
            )
        }
    }

    fun refresh() {
        viewModelScope.launch {
            _isRefreshing.value = true
            val result = repository.fetchWeather(currentCity)
            _isRefreshing.value = false

            result.fold(
                onSuccess = { data ->
                    val updatedStr = formatLastUpdated(data.lastUpdatedEpoch)
                    _uiState.value = HomeUiState.Success(data, isOffline = false, lastUpdatedText = updatedStr)
                },
                onFailure = { err ->
                    val cached = repository.getCachedWeatherData()
                    if (cached != null) {
                        val updatedStr = formatLastUpdated(cached.lastUpdatedEpoch)
                        _uiState.value = HomeUiState.Success(cached, isOffline = true, lastUpdatedText = updatedStr)
                    } else {
                        _uiState.value = HomeUiState.Error("Refresh failed: ${err.localizedMessage}")
                    }
                }
            )
        }
    }

    fun onSearchQueryChange(query: String) {
        _searchQuery.value = query
        searchJob?.cancel()

        if (query.isBlank()) {
            _searchResults.value = emptyList()
            _isSearching.value = false
            return
        }

        searchJob = viewModelScope.launch {
            delay(400) // 400ms debounce
            _isSearching.value = true
            val res = repository.searchCity(query.trim())
            _isSearching.value = false
            res.onSuccess { cities ->
                _searchResults.value = cities
            }.onFailure {
                _searchResults.value = emptyList()
            }
        }
    }

    fun selectCity(city: GeoPlace) {
        currentCity = city
        viewModelScope.launch {
            repository.saveLastCity(city)
            repository.addSavedCity(city)
            loadWeather(city)
        }
    }

    fun addSavedCity(city: GeoPlace) {
        viewModelScope.launch {
            repository.addSavedCity(city)
        }
    }

    fun removeSavedCity(city: GeoPlace) {
        viewModelScope.launch {
            repository.removeSavedCity(city)
        }
    }

    private fun formatLastUpdated(epochMs: Long): String {
        val diffMinutes = (System.currentTimeMillis() - epochMs) / (1000 * 60)
        return when {
            diffMinutes < 1 -> "Just now"
            diffMinutes < 60 -> "$diffMinutes min ago"
            else -> {
                val sdf = SimpleDateFormat("h:mm a", Locale.getDefault())
                sdf.format(Date(epochMs))
            }
        }
    }

    class Factory(private val repository: WeatherRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return HomeViewModel(repository) as T
        }
    }
}
