package com.anubhav.aakash.ui.home

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateIntAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.anubhav.aakash.R
import com.anubhav.aakash.data.model.AirQualityData
import com.anubhav.aakash.ui.theme.TextSecondary
import com.anubhav.aakash.ui.theme.glassCard

private data class AqiInfo(
    val category: String,
    val advice: String,
    val color: Color,
    val progress: Float
)

@Composable
private fun getAqiInfo(aqi: Int): AqiInfo {
    return when {
        aqi <= 50 -> AqiInfo(
            category = stringResource(R.string.aqi_cat_good),
            advice = stringResource(R.string.aqi_advice_good),
            color = Color(0xFF4ADE80),
            progress = (aqi / 50f * 0.16f).coerceIn(0f, 1f)
        )
        aqi <= 100 -> AqiInfo(
            category = stringResource(R.string.aqi_cat_moderate),
            advice = stringResource(R.string.aqi_advice_moderate),
            color = Color(0xFFFDE047),
            progress = (0.16f + (aqi - 50) / 50f * 0.17f).coerceIn(0f, 1f)
        )
        aqi <= 150 -> AqiInfo(
            category = stringResource(R.string.aqi_cat_sensitive),
            advice = stringResource(R.string.aqi_advice_sensitive),
            color = Color(0xFFFB923C),
            progress = (0.33f + (aqi - 100) / 50f * 0.17f).coerceIn(0f, 1f)
        )
        aqi <= 200 -> AqiInfo(
            category = stringResource(R.string.aqi_cat_unhealthy),
            advice = stringResource(R.string.aqi_advice_unhealthy),
            color = Color(0xFFF87171),
            progress = (0.50f + (aqi - 150) / 50f * 0.17f).coerceIn(0f, 1f)
        )
        aqi <= 300 -> AqiInfo(
            category = stringResource(R.string.aqi_cat_very_unhealthy),
            advice = stringResource(R.string.aqi_advice_unhealthy),
            color = Color(0xFFC084FC),
            progress = (0.67f + (aqi - 200) / 100f * 0.16f).coerceIn(0f, 1f)
        )
        else -> AqiInfo(
            category = stringResource(R.string.aqi_cat_hazardous),
            advice = stringResource(R.string.aqi_advice_unhealthy),
            color = Color(0xFF9F1239),
            progress = (0.83f + (aqi - 300) / 200f * 0.17f).coerceIn(0f, 1f)
        )
    }
}

@Composable
fun AqiCard(
    airQuality: AirQualityData?,
    modifier: Modifier = Modifier
) {
    if (airQuality == null) return

    val animatedAqi by animateIntAsState(
        targetValue = airQuality.usAqi,
        animationSpec = tween(durationMillis = 600, easing = FastOutSlowInEasing),
        label = "aqi_number"
    )

    val info = getAqiInfo(animatedAqi)

    Box(
        modifier = modifier
            .fillMaxWidth()
            .glassCard(RoundedCornerShape(24.dp))
            .padding(18.dp)
            .testTag("aqi_card")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = stringResource(R.string.aqi_section_title),
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    verticalAlignment = Alignment.Bottom
                ) {
                    Text(
                        text = "$animatedAqi",
                        fontSize = 48.sp,
                        fontWeight = FontWeight.Light,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(
                        modifier = Modifier.padding(bottom = 6.dp)
                    ) {
                        Text(
                            text = info.category,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = info.color
                        )
                        val pmText = when {
                            airQuality.pm25 != null -> "PM2.5: ${airQuality.pm25.toInt()} µg/m³"
                            airQuality.pm10 != null -> "PM10: ${airQuality.pm10.toInt()} µg/m³"
                            else -> null
                        }
                        if (pmText != null) {
                            Text(
                                text = pmText,
                                fontSize = 12.sp,
                                color = Color.White.copy(alpha = 0.60f)
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = info.advice,
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White.copy(alpha = 0.85f)
                )
            }

            Spacer(modifier = Modifier.width(16.dp))

            AqiVerticalGauge(
                progress = info.progress,
                modifier = Modifier
                    .width(8.dp)
                    .height(96.dp)
            )
        }
    }
}

@Composable
private fun AqiVerticalGauge(
    progress: Float,
    modifier: Modifier = Modifier
) {
    val animatedProgress by animateFloatAsState(
        targetValue = progress,
        animationSpec = tween(durationMillis = 600, easing = FastOutSlowInEasing),
        label = "aqi_gauge_progress"
    )

    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        val gradientBrush = Brush.verticalGradient(
            colors = listOf(
                Color(0xFF9F1239), // Hazardous (Top)
                Color(0xFFC084FC), // Very Unhealthy
                Color(0xFFF87171), // Unhealthy
                Color(0xFFFB923C), // Unhealthy for Sensitive
                Color(0xFFFDE047), // Moderate
                Color(0xFF4ADE80)  // Good (Bottom)
            )
        )

        drawRoundRect(
            brush = gradientBrush,
            cornerRadius = CornerRadius(w / 2, w / 2),
            size = size
        )

        val indicatorY = (h - w) * (1f - animatedProgress.coerceIn(0f, 1f)) + w / 2f

        drawCircle(
            color = Color.Black.copy(alpha = 0.35f),
            radius = w * 0.85f,
            center = Offset(w / 2f, indicatorY)
        )

        drawCircle(
            color = Color.White,
            radius = w * 0.65f,
            center = Offset(w / 2f, indicatorY)
        )
    }
}
