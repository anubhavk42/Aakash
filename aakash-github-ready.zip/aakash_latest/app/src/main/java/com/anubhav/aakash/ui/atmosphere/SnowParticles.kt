package com.anubhav.aakash.ui.atmosphere

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.isActive
import kotlin.math.sin
import kotlin.random.Random

private class SnowFlake(
    var x: Float = 0f,
    var y: Float = 0f,
    var radius: Float = 0f,
    var speed: Float = 0f,
    var alpha: Float = 0.5f,
    var phase: Float = 0f
)

@Composable
fun SnowParticles(
    modifier: Modifier = Modifier
) {
    val density = LocalDensity.current
    val count = 140

    val flakes = remember {
        Array(count) { SnowFlake() }
    }

    val isInitialized = remember { BooleanArray(1) { false } }
    val frameState = remember { androidx.compose.runtime.mutableLongStateOf(0L) }

    LaunchedEffect(Unit) {
        var lastNanos = 0L
        while (isActive) {
            withFrameNanos { nanos ->
                if (lastNanos != 0L) {
                    val dt = ((nanos - lastNanos) / 1_000_000_000f).coerceAtMost(0.05f)
                    frameState.longValue = nanos

                    for (flake in flakes) {
                        flake.y += flake.speed * dt * 250f
                        flake.phase += dt * 1.5f
                        flake.x += sin(flake.phase + flake.y * 0.005f) * 1.2f

                        if (flake.y > 2500f) {
                            flake.y = -flake.radius - Random.nextFloat() * 50f
                            flake.x = Random.nextFloat() * 1500f
                        }
                    }
                }
                lastNanos = nanos
            }
        }
    }

    Canvas(modifier = modifier.fillMaxSize()) {
        val width = size.width
        val height = size.height

        if (!isInitialized[0] && width > 0 && height > 0) {
            for (flake in flakes) {
                flake.x = Random.nextFloat() * width
                flake.y = Random.nextFloat() * height
                flake.radius = with(density) { (2 + Random.nextFloat() * 3).dp.toPx() }
                flake.speed = (0.5f + Random.nextFloat() * 1.0f) * with(density) { 3.dp.toPx() }
                flake.alpha = 0.3f + Random.nextFloat() * 0.5f
                flake.phase = Random.nextFloat() * 6.28f
            }
            isInitialized[0] = true
        }

        @Suppress("UNUSED_VARIABLE")
        val dummy = frameState.longValue

        for (flake in flakes) {
            drawCircle(
                color = Color.White.copy(alpha = flake.alpha),
                radius = flake.radius,
                center = Offset(flake.x, flake.y)
            )
        }
    }
}
