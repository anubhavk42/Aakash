package com.anubhav.aakash.ui.atmosphere

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import com.anubhav.aakash.data.model.WeatherKind
import kotlinx.coroutines.isActive
import kotlin.random.Random

private class RainDrop(
    var x: Float = 0f,
    var y: Float = 0f,
    var length: Float = 0f,
    var speed: Float = 0f,
    var alpha: Float = 0.3f,
    var strokeWidth: Float = 2f
)

@Composable
fun RainParticles(
    kind: WeatherKind,
    modifier: Modifier = Modifier
) {
    val density = LocalDensity.current
    val count = when (kind) {
        WeatherKind.STORM -> 280
        WeatherKind.DRIZZLE -> 90
        else -> 180
    }

    val drops = remember(count) {
        Array(count) { RainDrop() }
    }

    val isInitialized = remember(count) { BooleanArray(1) { false } }

    val frameState = remember { androidx.compose.runtime.mutableLongStateOf(0L) }

    LaunchedEffect(count) {
        var lastNanos = 0L
        while (isActive) {
            withFrameNanos { nanos ->
                if (lastNanos != 0L) {
                    val dt = ((nanos - lastNanos) / 1_000_000_000f).coerceAtMost(0.05f)
                    frameState.longValue = nanos
                    // Update particles in place
                    val isStorm = kind == WeatherKind.STORM
                    val isDrizzle = kind == WeatherKind.DRIZZLE

                    val speedMult = when {
                        isStorm -> 1.6f
                        isDrizzle -> 0.7f
                        else -> 1.0f
                    }

                    for (drop in drops) {
                        drop.y += drop.speed * speedMult * dt * 600f
                        drop.x += drop.speed * 0.25f * speedMult * dt * 600f // diagonal slant

                        // Wrap around
                        if (drop.y > 2500f) {
                            drop.y = -drop.length - Random.nextFloat() * 100f
                            drop.x = Random.nextFloat() * 1500f
                        }
                    }
                }
                lastNanos = nanos
            }
        }
    }

    Canvas(modifier = modifier.fillMaxSize()) {
        val width = size.width
        val height = size.height

        if (!isInitialized[0] && width > 0 && height > 0) {
            val isStorm = kind == WeatherKind.STORM
            val isDrizzle = kind == WeatherKind.DRIZZLE

            val strokeMin = if (isDrizzle) 1.5f else if (isStorm) 3.5f else 2.0f
            val strokeMax = if (isDrizzle) 2.5f else if (isStorm) 5.0f else 3.5f

            for (drop in drops) {
                drop.x = Random.nextFloat() * (width + 300f) - 150f
                drop.y = Random.nextFloat() * height
                drop.length = with(density) {
                    if (isDrizzle) (8 + Random.nextFloat() * 8).dp.toPx()
                    else if (isStorm) (25 + Random.nextFloat() * 20).dp.toPx()
                    else (15 + Random.nextFloat() * 12).dp.toPx()
                }
                drop.speed = (1.2f + Random.nextFloat() * 1.5f) * with(density) { 6.dp.toPx() }
                drop.alpha = if (isDrizzle) 0.15f + Random.nextFloat() * 0.2f else 0.25f + Random.nextFloat() * 0.35f
                drop.strokeWidth = with(density) { (strokeMin + Random.nextFloat() * (strokeMax - strokeMin)).dp.toPx() }
            }
            isInitialized[0] = true
        }

        // Trigger redraw via frameState reading
        @Suppress("UNUSED_VARIABLE")
        val dummy = frameState.longValue

        for (drop in drops) {
            drawLine(
                color = Color.White.copy(alpha = drop.alpha),
                start = Offset(drop.x, drop.y),
                end = Offset(drop.x + drop.length * 0.25f, drop.y + drop.length),
                strokeWidth = drop.strokeWidth,
                cap = StrokeCap.Round
            )
        }
    }
}
