package com.anubhav.aakash.ui.theme

import androidx.compose.ui.graphics.Color

// Indigo gradient base palette
val IndigoBaseDark = Color(0xFF0B0B26)
val IndigoBaseMedium = Color(0xFF1A194D)
val IndigoBaseLight = Color(0xFF2B286C)
val IndigoBaseNight = Color(0xFF07071A)

// Condition Gradient Color Pairs (Start -> End)
val ClearDayStart = Color(0xFF1E3C72)
val ClearDayEnd = Color(0xFF2A5298)

val ClearNightStart = Color(0xFF090A0F)
val ClearNightEnd = Color(0xFF1A1C29)

val CloudyDayStart = Color(0xFF203A43)
val CloudyDayEnd = Color(0xFF2C5364)

val DrizzleStart = Color(0xFF2C3E50)
val DrizzleEnd = Color(0xFF3498DB)

val RainStart = Color(0xFF1F1C2C)
val RainEnd = Color(0xFF928DAB)

val StormStart = Color(0xFF0F0C20)
val StormEnd = Color(0xFF241442)

val SnowStart = Color(0xFF232526)
val SnowEnd = Color(0xFF414345)

val FogStart = Color(0xFF3E5151)
val FogEnd = Color(0xFFDECBA4)

val OvercastDayStart = Color(0xFF4A5A6A)
val OvercastDayEnd = Color(0xFF2B3642)
val OvercastNightStart = Color(0xFF607080)
val OvercastNightEnd = Color(0xFF22242E)

// Glass & Accents
val GlassBackground = Color(0x24FFFFFF)
val GlassBackgroundLight = Color(0x38FFFFFF)
val GlassBorder = Color(0x40FFFFFF)
val GlassHighlight = Color(0xFF8FC7FF)

val CyanAccent = Color(0xFF00F2FE)
val PurpleAccent = Color(0xFF7F00FF)
val GoldAccent = Color(0xFFFFB300)
val CoralAccent = Color(0xFFFF5252)

val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xB3FFFFFF)
val TextMuted = Color(0x80FFFFFF)
