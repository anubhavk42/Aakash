package com.anubhav.aakash.ui.home

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateIntAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Air
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Compress
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Thunderstorm
import androidx.compose.material.icons.filled.WbCloudy
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material.icons.filled.WbTwilight
import androidx.compose.material.icons.outlined.WaterDrop
import androidx.compose.material.icons.outlined.WbSunny
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.anubhav.aakash.data.model.computeDayPhase
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.anubhav.aakash.data.model.DailyItem
import com.anubhav.aakash.data.model.HourlyItem
import com.anubhav.aakash.data.model.WeatherData
import com.anubhav.aakash.data.model.WeatherKind
import com.anubhav.aakash.ui.atmosphere.AtmosphereBackground
import com.anubhav.aakash.ui.common.HomeScreenShimmer
import com.anubhav.aakash.ui.common.UnitUtils
import com.anubhav.aakash.ui.common.rememberHapticHelper
import com.anubhav.aakash.ui.search.SearchSheet
import com.anubhav.aakash.ui.theme.CyanAccent
import com.anubhav.aakash.ui.theme.GlassBackground
import com.anubhav.aakash.ui.theme.GlassBorder
import com.anubhav.aakash.ui.theme.GlassHighlight
import com.anubhav.aakash.ui.theme.GoldAccent
import com.anubhav.aakash.ui.theme.TextPrimary
import com.anubhav.aakash.ui.theme.TextSecondary
import com.anubhav.aakash.ui.theme.glassCard

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: HomeViewModel,
    onNavigateToForecast: () -> Unit,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val isRefreshing by viewModel.isRefreshing.collectAsState()
    val tempUnit by viewModel.tempUnit.collectAsState()
    val speedUnit by viewModel.speedUnit.collectAsState()
    val animationsEnabled by viewModel.animationsEnabled.collectAsState()
    val hapticsEnabled by viewModel.hapticsEnabled.collectAsState()
    val savedCities by viewModel.savedCities.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val searchResults by viewModel.searchResults.collectAsState()
    val isSearching by viewModel.isSearching.collectAsState()

    val hapticHelper = rememberHapticHelper()
    var showSearchSheet by remember { mutableStateOf(false) }

    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                viewModel.checkAndSilentRefresh()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    var currentTimeMillis by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (isActive) {
            delay(60_000L)
            currentTimeMillis = System.currentTimeMillis()
        }
    }

    val weatherData = (uiState as? HomeUiState.Success)?.data
    val currentKind = weatherData?.current?.weatherKind ?: WeatherKind.CLEAR

    val dayPhase = remember(currentTimeMillis, weatherData) {
        computeDayPhase(
            nowMillis = currentTimeMillis,
            sunriseMillis = weatherData?.sunriseEpochMillis,
            sunsetMillis = weatherData?.sunsetEpochMillis,
            fallbackIsNight = weatherData?.current?.isNight ?: false
        )
    }

    AtmosphereBackground(
        kind = currentKind,
        phase = dayPhase,
        animationsEnabled = animationsEnabled,
        modifier = modifier
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
        ) {
            when (val state = uiState) {
                is HomeUiState.Loading, HomeUiState.Idle -> {
                    HomeScreenShimmer()
                }

                is HomeUiState.Error -> {
                    ErrorStateView(
                        message = state.message,
                        onRetry = {
                            hapticHelper.triggerClick(hapticsEnabled)
                            viewModel.loadWeather()
                        }
                    )
                }

                is HomeUiState.Success -> {
                    PullToRefreshBox(
                        isRefreshing = isRefreshing,
                        onRefresh = {
                            hapticHelper.triggerTick(hapticsEnabled)
                            viewModel.refresh()
                        },
                        modifier = Modifier.fillMaxSize()
                    ) {
                        HomeContent(
                            data = state.data,
                            isOffline = state.isOffline,
                            lastUpdatedText = state.lastUpdatedText,
                            tempUnit = tempUnit,
                            speedUnit = speedUnit,
                            hapticsEnabled = hapticsEnabled,
                            onSearchClick = {
                                hapticHelper.triggerClick(hapticsEnabled)
                                showSearchSheet = true
                            },
                            onNavigateToForecast = {
                                hapticHelper.triggerClick(hapticsEnabled)
                                onNavigateToForecast()
                            },
                            onHourClick = {
                                hapticHelper.triggerTick(hapticsEnabled)
                            }
                        )
                    }
                }
            }
        }

        if (showSearchSheet) {
            SearchSheet(
                query = searchQuery,
                onQueryChange = { viewModel.onSearchQueryChange(it) },
                results = searchResults,
                isSearching = isSearching,
                savedCities = savedCities,
                tempUnit = tempUnit,
                hapticsEnabled = hapticsEnabled,
                onCitySelect = { city ->
                    hapticHelper.triggerClick(hapticsEnabled)
                    viewModel.selectCity(city)
                    showSearchSheet = false
                },
                onRemoveSavedCity = { city ->
                    hapticHelper.triggerTick(hapticsEnabled)
                    viewModel.removeSavedCity(city)
                },
                onDismiss = { showSearchSheet = false }
            )
        }
    }
}

@Composable
private fun HomeContent(
    data: WeatherData,
    isOffline: Boolean,
    lastUpdatedText: String,
    tempUnit: String,
    speedUnit: String,
    hapticsEnabled: Boolean,
    onSearchClick: () -> Unit,
    onNavigateToForecast: () -> Unit,
    onHourClick: () -> Unit
) {
    val scrollState = rememberScrollState()
    var isVisible by remember { mutableStateOf(false) }

    LaunchedEffect(data.city.id) {
        isVisible = true
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(bottom = 100.dp)
    ) {
        // Offline Glass Banner
        if (isOffline) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
                    .glassCard(RoundedCornerShape(12.dp), opacity = 0.2f)
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Last updated $lastUpdatedText · Offline",
                    color = GoldAccent,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }

        // Top Bar: Location Pin + City Name + Search Icon
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Filled.LocationOn,
                    contentDescription = "Location",
                    tint = CyanAccent,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = data.city.name,
                        style = MaterialTheme.typography.titleLarge,
                        color = TextPrimary
                    )
                    if (data.city.country.isNotBlank()) {
                        Text(
                            text = if (data.city.admin1.isNotBlank()) "${data.city.admin1}, ${data.city.country}" else data.city.country,
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary
                        )
                    }
                }
            }

            IconButton(
                onClick = onSearchClick,
                modifier = Modifier
                    .testTag("search_button")
                    .clip(CircleShape)
                    .background(GlassBackground)
                    .border(1.dp, GlassBorder, CircleShape)
            ) {
                Icon(
                    imageVector = Icons.Filled.Search,
                    contentDescription = "Search",
                    tint = TextPrimary
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Hero Temperature & Condition
        val targetTempRaw = UnitUtils.formatTempRaw(data.current.temperature, tempUnit)
        val animatedTemp by animateIntAsState(
            targetValue = targetTempRaw,
            label = "hero_temp"
        )

        AnimatedVisibility(
            visible = isVisible,
            enter = fadeIn() + slideInVertically { -30 }
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "$animatedTemp°",
                    style = MaterialTheme.typography.displayLarge,
                    modifier = Modifier.testTag("hero_temp_text")
                )
                Text(
                    text = data.current.weatherDescription,
                    style = MaterialTheme.typography.titleLarge,
                    color = TextPrimary
                )
                Spacer(modifier = Modifier.height(4.dp))
                val feelsLikeFormatted = UnitUtils.formatTemp(data.current.feelsLike, tempUnit)
                Text(
                    text = "Feels like $feelsLikeFormatted",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
            }
        }

        Spacer(modifier = Modifier.height(32.dp))

        // Horizontal Hourly Strip
        Column(
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = "HOURLY FORECAST",
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
            )

            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(data.hourly) { item ->
                    HourlyPillItem(
                        item = item,
                        tempUnit = tempUnit,
                        onClick = onHourClick
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Air Quality Hero Card (if available)
        if (data.airQuality != null) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
            ) {
                AqiCard(airQuality = data.airQuality)
            }
            Spacer(modifier = Modifier.height(20.dp))
        }

        // 2x2 Glass Stat Grid
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
        ) {
            Text(
                text = "CURRENT CONDITIONS",
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary,
                modifier = Modifier.padding(vertical = 8.dp)
            )

            Row(modifier = Modifier.fillMaxWidth()) {
                StatCard(
                    title = "HUMIDITY",
                    value = "${data.current.humidity}%",
                    sublabel = if (data.current.humidity > 70) "High moisture" else "Comfortable",
                    icon = Icons.Outlined.WaterDrop,
                    modifier = Modifier.weight(1f)
                )
                Spacer(modifier = Modifier.width(12.dp))
                StatCard(
                    title = "WIND",
                    value = UnitUtils.formatSpeed(data.current.windSpeed, speedUnit),
                    sublabel = "Surface speed",
                    icon = Icons.Filled.Air,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(modifier = Modifier.fillMaxWidth()) {
                StatCard(
                    title = "UV INDEX",
                    value = "${data.current.uvIndex.toInt()}",
                    sublabel = when {
                        data.current.uvIndex < 3 -> "Low"
                        data.current.uvIndex < 6 -> "Moderate"
                        data.current.uvIndex < 8 -> "High"
                        else -> "Very High"
                    },
                    icon = Icons.Outlined.WbSunny,
                    modifier = Modifier.weight(1f)
                )
                Spacer(modifier = Modifier.width(12.dp))
                StatCard(
                    title = "PRESSURE",
                    value = "${data.current.pressure.toInt()} hPa",
                    sublabel = "Atmospheric",
                    icon = Icons.Filled.Compress,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // 7-Day Preview Card
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .glassCard(RoundedCornerShape(24.dp))
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "7-DAY FORECAST PREVIEW",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary
                )
                Row(
                    modifier = Modifier
                        .testTag("view_full_forecast_button")
                        .clickable { onNavigateToForecast() },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Full Forecast",
                        style = MaterialTheme.typography.labelLarge,
                        color = CyanAccent
                    )
                    Icon(
                        imageVector = Icons.Filled.ChevronRight,
                        contentDescription = "Full Forecast",
                        tint = CyanAccent,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            data.daily.take(3).forEach { day ->
                DailyPreviewRow(day = day, tempUnit = tempUnit)
                Spacer(modifier = Modifier.height(8.dp))
            }
        }
    }
}

@Composable
private fun HourlyPillItem(
    item: HourlyItem,
    tempUnit: String,
    onClick: () -> Unit
) {
    val borderColor = if (item.isNow) GlassHighlight else GlassBorder
    val borderWidth = if (item.isNow) 1.5.dp else 1.dp

    Column(
        modifier = Modifier
            .width(68.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(if (item.isNow) GlassHighlight.copy(alpha = 0.2f) else GlassBackground)
            .border(borderWidth, borderColor, RoundedCornerShape(20.dp))
            .clickable { onClick() }
            .padding(vertical = 12.dp, horizontal = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = if (item.isNow) "NOW" else item.time,
            style = MaterialTheme.typography.labelSmall,
            color = if (item.isNow) CyanAccent else TextSecondary,
            fontWeight = if (item.isNow) FontWeight.Bold else FontWeight.Normal
        )

        Spacer(modifier = Modifier.height(8.dp))

        Icon(
            imageVector = getWeatherIcon(item.weatherKind),
            contentDescription = item.weatherKind.description,
            tint = TextPrimary,
            modifier = Modifier.size(24.dp)
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = UnitUtils.formatTemp(item.temp, tempUnit),
            style = MaterialTheme.typography.labelLarge,
            color = TextPrimary
        )

        if (item.precipProb > 0) {
            Text(
                text = "${item.precipProb}%",
                fontSize = 10.sp,
                color = CyanAccent
            )
        }
    }
}

@Composable
private fun StatCard(
    title: String,
    value: String,
    sublabel: String,
    icon: ImageVector,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .glassCard(RoundedCornerShape(20.dp))
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary
            )
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = CyanAccent,
                modifier = Modifier.size(20.dp)
            )
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.titleMedium,
            color = TextPrimary,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = sublabel,
            style = MaterialTheme.typography.labelSmall,
            color = TextSecondary
        )
    }
}

@Composable
private fun DailyPreviewRow(
    day: DailyItem,
    tempUnit: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = day.dayName,
            style = MaterialTheme.typography.labelLarge,
            color = TextPrimary,
            modifier = Modifier.width(60.dp)
        )

        Icon(
            imageVector = getWeatherIcon(day.weatherKind),
            contentDescription = day.weatherKind.description,
            tint = TextPrimary,
            modifier = Modifier.size(20.dp)
        )

        // Gradient Temp Bar
        Box(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 12.dp)
                .height(6.dp)
                .clip(CircleShape)
                .background(
                    Brush.horizontalGradient(
                        colors = listOf(CyanAccent.copy(alpha = 0.6f), GoldAccent.copy(alpha = 0.8f))
                    )
                )
        )

        Text(
            text = "${UnitUtils.formatTemp(day.tempMin, tempUnit)} / ${UnitUtils.formatTemp(day.tempMax, tempUnit)}",
            style = MaterialTheme.typography.labelMedium,
            color = TextSecondary
        )
    }
}

@Composable
private fun ErrorStateView(
    message: String,
    onRetry: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .glassCard(RoundedCornerShape(24.dp))
                .padding(24.dp)
        ) {
            Icon(
                imageVector = Icons.Filled.Refresh,
                contentDescription = "Error",
                tint = GoldAccent,
                modifier = Modifier.size(48.dp)
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = message,
                style = MaterialTheme.typography.bodyLarge,
                color = TextPrimary,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
            Spacer(modifier = Modifier.height(20.dp))
            Button(
                onClick = onRetry,
                colors = ButtonDefaults.buttonColors(containerColor = CyanAccent)
            ) {
                Text(text = "Retry", color = Color.Black, fontWeight = FontWeight.Bold)
            }
        }
    }
}

fun getWeatherIcon(kind: WeatherKind): ImageVector {
    return when (kind) {
        WeatherKind.CLEAR -> Icons.Filled.WbSunny
        WeatherKind.CLOUDY -> Icons.Filled.WbCloudy
        WeatherKind.OVERCAST -> Icons.Filled.Cloud
        WeatherKind.DRIZZLE -> Icons.Outlined.WaterDrop
        WeatherKind.RAIN -> Icons.Filled.Cloud
        WeatherKind.STORM -> Icons.Filled.Thunderstorm
        WeatherKind.SNOW -> Icons.Filled.WbTwilight
        WeatherKind.FOG -> Icons.Filled.WbCloudy
    }
}
