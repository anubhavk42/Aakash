package com.anubhav.aakash.data.api

import com.anubhav.aakash.data.model.AirQualityResponse
import com.anubhav.aakash.data.model.GeocodingResponse
import com.anubhav.aakash.data.model.Minutely15Response
import com.anubhav.aakash.data.model.OpenMeteoResponse
import retrofit2.http.GET
import retrofit2.http.Query

interface OpenMeteoService {

    @GET("https://api.open-meteo.com/v1/forecast")
    suspend fun getWeatherForecast(
        @Query("latitude") lat: Double,
        @Query("longitude") lon: Double,
        @Query("current") current: String = "temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,weather_code,surface_pressure,wind_speed_10m,uv_index",
        @Query("hourly") hourly: String = "temperature_2m,weather_code,precipitation_probability",
        @Query("daily") daily: String = "weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum,precipitation_probability_max,sunrise,sunset",
        @Query("timezone") timezone: String = "auto",
        @Query("timeformat") timeformat: String = "unixtime"
    ): OpenMeteoResponse

    @GET("https://api.open-meteo.com/v1/forecast")
    suspend fun getMinutelyPrecipitation(
        @Query("latitude") lat: Double,
        @Query("longitude") lon: Double,
        @Query("minutely_15") minutely15: String = "precipitation",
        @Query("forecast_minutely_15") forecastMinutely15: Int = 8,
        @Query("timezone") timezone: String = "auto",
        @Query("timeformat") timeformat: String = "unixtime"
    ): Minutely15Response

    @GET("https://geocoding-api.open-meteo.com/v1/search")
    suspend fun searchCity(
        @Query("name") name: String,
        @Query("count") count: Int = 10,
        @Query("language") language: String = "en",
        @Query("format") format: String = "json"
    ): GeocodingResponse

    // Using full URL directly on @GET keeps a single Retrofit instance in AppContainer while querying the separate Air Quality domain
    @GET("https://air-quality-api.open-meteo.com/v1/air-quality")
    suspend fun getAirQuality(
        @Query("latitude") lat: Double,
        @Query("longitude") lon: Double,
        @Query("current") current: String = "us_aqi,pm2_5,pm10",
        @Query("timezone") timezone: String = "auto"
    ): AirQualityResponse
}
