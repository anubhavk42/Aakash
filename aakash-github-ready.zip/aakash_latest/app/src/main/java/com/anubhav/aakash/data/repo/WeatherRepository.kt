package com.anubhav.aakash.data.repo

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.anubhav.aakash.data.api.OpenMeteoService
import com.anubhav.aakash.data.model.AirQualityData
import com.anubhav.aakash.data.model.CurrentWeather
import com.anubhav.aakash.data.model.DailyItem
import com.anubhav.aakash.data.model.GeoPlace
import com.anubhav.aakash.data.model.HourlyItem
import com.anubhav.aakash.data.model.WeatherData
import com.anubhav.aakash.data.model.WeatherKind
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "aakash_settings")

class WeatherRepository(
    private val api: OpenMeteoService,
    private val dataStore: DataStore<Preferences>,
    private val gson: Gson
) {
    companion object {
        private val KEY_CACHED_WEATHER = stringPreferencesKey("cached_weather_json")
        private val KEY_SAVED_CITIES = stringPreferencesKey("saved_cities_json")
        private val KEY_TEMP_UNIT = stringPreferencesKey("temp_unit") // "C" or "F"
        private val KEY_SPEED_UNIT = stringPreferencesKey("speed_unit") // "kmh" or "mph"
        private val KEY_ANIMATIONS = booleanPreferencesKey("animations_enabled")
        private val KEY_HAPTICS = booleanPreferencesKey("haptics_enabled")
        private val KEY_DARK_MODE = booleanPreferencesKey("dark_mode_enabled")
        private val KEY_LAST_CITY = stringPreferencesKey("last_selected_city")

        val DEFAULT_CITY = GeoPlace(
            id = 1273294L,
            name = "Delhi",
            latitude = 28.6139,
            longitude = 77.2090,
            country = "India",
            admin1 = "Delhi"
        )
    }

    // Preferences Flows
    val tempUnitFlow: Flow<String> = dataStore.data.map { prefs ->
        prefs[KEY_TEMP_UNIT] ?: "C"
    }

    val speedUnitFlow: Flow<String> = dataStore.data.map { prefs ->
        prefs[KEY_SPEED_UNIT] ?: "kmh"
    }

    val animationsFlow: Flow<Boolean> = dataStore.data.map { prefs ->
        prefs[KEY_ANIMATIONS] ?: true
    }

    val hapticsFlow: Flow<Boolean> = dataStore.data.map { prefs ->
        prefs[KEY_HAPTICS] ?: true
    }

    val darkModeFlow: Flow<Boolean> = dataStore.data.map { prefs ->
        prefs[KEY_DARK_MODE] ?: true
    }

    val savedCitiesFlow: Flow<List<GeoPlace>> = dataStore.data.map { prefs ->
        val json = prefs[KEY_SAVED_CITIES]
        if (json.isNullOrBlank()) {
            listOf(DEFAULT_CITY)
        } else {
            try {
                val type = object : TypeToken<List<GeoPlace>>() {}.type
                gson.fromJson(json, type) ?: listOf(DEFAULT_CITY)
            } catch (e: Exception) {
                listOf(DEFAULT_CITY)
            }
        }
    }

    val lastSelectedCityFlow: Flow<GeoPlace> = dataStore.data.map { prefs ->
        val json = prefs[KEY_LAST_CITY]
        if (json.isNullOrBlank()) {
            DEFAULT_CITY
        } else {
            try {
                gson.fromJson(json, GeoPlace::class.java) ?: DEFAULT_CITY
            } catch (e: Exception) {
                DEFAULT_CITY
            }
        }
    }

    suspend fun setTempUnit(unit: String) {
        dataStore.edit { prefs -> prefs[KEY_TEMP_UNIT] = unit }
    }

    suspend fun setSpeedUnit(unit: String) {
        dataStore.edit { prefs -> prefs[KEY_SPEED_UNIT] = unit }
    }

    suspend fun setAnimationsEnabled(enabled: Boolean) {
        dataStore.edit { prefs -> prefs[KEY_ANIMATIONS] = enabled }
    }

    suspend fun setHapticsEnabled(enabled: Boolean) {
        dataStore.edit { prefs -> prefs[KEY_HAPTICS] = enabled }
    }

    suspend fun setDarkModeEnabled(enabled: Boolean) {
        dataStore.edit { prefs -> prefs[KEY_DARK_MODE] = enabled }
    }

    suspend fun saveLastCity(place: GeoPlace) {
        val json = gson.toJson(place)
        dataStore.edit { prefs -> prefs[KEY_LAST_CITY] = json }
    }

    suspend fun addSavedCity(place: GeoPlace) {
        val current = savedCitiesFlow.first().toMutableList()
        if (current.none { it.id == place.id || (it.latitude == place.latitude && it.longitude == place.longitude) }) {
            current.add(0, place)
            val json = gson.toJson(current)
            dataStore.edit { prefs -> prefs[KEY_SAVED_CITIES] = json }
        }
    }

    suspend fun removeSavedCity(place: GeoPlace) {
        val current = savedCitiesFlow.first().toMutableList()
        current.removeAll { it.id == place.id || (it.name.equals(place.name, ignoreCase = true) && it.country == place.country) }
        val json = gson.toJson(current)
        dataStore.edit { prefs -> prefs[KEY_SAVED_CITIES] = json }
    }

    suspend fun searchCity(name: String): Result<List<GeoPlace>> = runCatching {
        val response = api.searchCity(name = name)
        response.results?.map { dto ->
            GeoPlace(
                id = dto.id,
                name = dto.name,
                latitude = dto.latitude,
                longitude = dto.longitude,
                country = dto.country ?: "",
                admin1 = dto.admin1 ?: ""
            )
        } ?: emptyList()
    }

    suspend fun fetchWeather(place: GeoPlace): Result<WeatherData> = runCatching {
        try {
            coroutineScope {
                val forecastDeferred = async { api.getWeatherForecast(lat = place.latitude, lon = place.longitude) }
                val aqiDeferred = async {
                    runCatching {
                        api.getAirQuality(lat = place.latitude, lon = place.longitude)
                    }.getOrNull()
                }

                val res = forecastDeferred.await()
                val aqiRes = aqiDeferred.await()

                val currentDto = res.current
                val hourlyDto = res.hourly
                val dailyDto = res.daily

                val wCode = currentDto?.weatherCode ?: 0
                val kind = WeatherKind.fromWmoCode(wCode)
                val isNight = (currentDto?.isDay ?: 1) == 0

                val current = CurrentWeather(
                    temperature = currentDto?.temperature2m ?: 0.0,
                    feelsLike = currentDto?.apparentTemperature ?: 0.0,
                    humidity = currentDto?.relativeHumidity2m ?: 0,
                    windSpeed = currentDto?.windSpeed10m ?: 0.0,
                    pressure = currentDto?.surfacePressure ?: 1013.25,
                    uvIndex = currentDto?.uvIndex ?: 0.0,
                    precipitation = currentDto?.precipitation ?: 0.0,
                    weatherKind = kind,
                    isNight = isNight,
                    weatherDescription = kind.description
                )

                // Process hourly
                val hourlyItems = mutableListOf<HourlyItem>()
                val currentHourIndex = calculateCurrentHourIndex(hourlyDto?.time)
                val times = hourlyDto?.time ?: emptyList()
                val temps = hourlyDto?.temperature2m ?: emptyList()
                val codes = hourlyDto?.weatherCode ?: emptyList()
                val precips = hourlyDto?.precipitationProbability ?: emptyList()

                val startIndex = if (currentHourIndex >= 0) currentHourIndex else 0
                val endIndex = (startIndex + 24).coerceAtMost(times.size)

                for (i in startIndex until endIndex) {
                    val rawSec = times.getOrNull(i) ?: 0L
                    val formattedTime = formatHourlyTimeFromEpoch(rawSec * 1000L)
                    val temp = temps.getOrNull(i) ?: 0.0
                    val hCode = codes.getOrNull(i) ?: 0
                    val pProb = precips.getOrNull(i) ?: 0

                    hourlyItems.add(
                        HourlyItem(
                            time = formattedTime,
                            temp = temp,
                            weatherKind = WeatherKind.fromWmoCode(hCode),
                            precipProb = pProb,
                            isNow = (i == startIndex)
                        )
                    )
                }

                // Process daily
                val dailyItems = mutableListOf<DailyItem>()
                val dTimes = dailyDto?.time ?: emptyList()
                val dCodes = dailyDto?.weatherCode ?: emptyList()
                val dMaxs = dailyDto?.temperature2mMax ?: emptyList()
                val dMins = dailyDto?.temperature2mMin ?: emptyList()
                val dPrecips = dailyDto?.precipitationProbabilityMax ?: emptyList()
                val dSunrises = dailyDto?.sunrise ?: emptyList()
                val dSunsets = dailyDto?.sunset ?: emptyList()

                for (i in dTimes.indices) {
                    val rawSec = dTimes[i]
                    val dayName = formatDailyDayNameFromEpoch(rawSec * 1000L, i)
                    val dCode = dCodes.getOrNull(i) ?: 0
                    val minTemp = dMins.getOrNull(i) ?: 0.0
                    val maxTemp = dMaxs.getOrNull(i) ?: 0.0
                    val pProb = dPrecips.getOrNull(i) ?: 0
                    val sunriseMs = (dSunrises.getOrNull(i) ?: 0L) * 1000L
                    val sunsetMs = (dSunsets.getOrNull(i) ?: 0L) * 1000L
                    val sunriseStr = formatTimeFromEpoch(sunriseMs)
                    val sunsetStr = formatTimeFromEpoch(sunsetMs)

                    dailyItems.add(
                        DailyItem(
                            date = formatIsoDateFromEpoch(rawSec * 1000L),
                            dayName = dayName,
                            weatherKind = WeatherKind.fromWmoCode(dCode),
                            tempMin = minTemp,
                            tempMax = maxTemp,
                            precipProb = pProb,
                            sunrise = sunriseStr.ifBlank { "06:12 AM" },
                            sunset = sunsetStr.ifBlank { "06:48 PM" },
                            humidity = currentDto?.relativeHumidity2m ?: 65
                        )
                    )
                }

                val aqiData = aqiRes?.current?.usAqi?.let { aqi ->
                    AirQualityData(
                        usAqi = aqi,
                        pm25 = aqiRes.current.pm25,
                        pm10 = aqiRes.current.pm10
                    )
                }

                val todaySunriseEpochMs = dSunrises.getOrNull(0)?.takeIf { it > 0 }?.let { it * 1000L }
                val todaySunsetEpochMs = dSunsets.getOrNull(0)?.takeIf { it > 0 }?.let { it * 1000L }

                val weatherData = WeatherData(
                    city = place,
                    current = current,
                    hourly = hourlyItems,
                    daily = dailyItems,
                    airQuality = aqiData,
                    lastUpdatedEpoch = System.currentTimeMillis(),
                    sunriseEpochMillis = todaySunriseEpochMs,
                    sunsetEpochMillis = todaySunsetEpochMs
                )

                // Cache in DataStore
                saveCachedWeatherData(weatherData)
                saveLastCity(place)

                weatherData
            }
        } catch (e: Exception) {
            // Offline fallback
            val cached = getCachedWeatherData()
            if (cached != null) {
                cached
            } else {
                throw e
            }
        }
    }

    private suspend fun saveCachedWeatherData(data: WeatherData) {
        val json = gson.toJson(data)
        dataStore.edit { prefs -> prefs[KEY_CACHED_WEATHER] = json }
    }

    suspend fun getCachedWeatherData(): WeatherData? {
        val prefs = dataStore.data.first()
        val json = prefs[KEY_CACHED_WEATHER] ?: return null
        return try {
            gson.fromJson(json, WeatherData::class.java)
        } catch (e: Exception) {
            null
        }
    }

    private fun calculateCurrentHourIndex(times: List<Long>?): Int {
        if (times.isNullOrEmpty()) return -1
        val nowSec = System.currentTimeMillis() / 1000L
        val idx = times.indexOfFirst { it >= nowSec - 1800L }
        return if (idx >= 0) idx else 0
    }

    private fun formatHourlyTimeFromEpoch(epochMs: Long): String {
        if (epochMs <= 0L) return ""
        val sdf = SimpleDateFormat("h a", Locale.getDefault())
        return sdf.format(Date(epochMs))
    }

    private fun formatDailyDayNameFromEpoch(epochMs: Long, index: Int): String {
        if (index == 0) return "Today"
        if (epochMs <= 0L) return ""
        val sdf = SimpleDateFormat("EEE", Locale.getDefault())
        return sdf.format(Date(epochMs))
    }

    private fun formatTimeFromEpoch(epochMs: Long): String {
        if (epochMs <= 0L) return ""
        val sdf = SimpleDateFormat("hh:mm a", Locale.getDefault())
        return sdf.format(Date(epochMs))
    }

    private fun formatIsoDateFromEpoch(epochMs: Long): String {
        if (epochMs <= 0L) return ""
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        return sdf.format(Date(epochMs))
    }
}
