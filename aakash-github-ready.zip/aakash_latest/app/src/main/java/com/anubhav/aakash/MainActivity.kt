package com.anubhav.aakash

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.ExperimentalSharedTransitionApi
import androidx.compose.animation.SharedTransitionLayout
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.navigation.compose.rememberNavController
import com.anubhav.aakash.di.AppContainer
import com.anubhav.aakash.navigation.AakashNavHost
import com.anubhav.aakash.ui.home.HomeViewModel
import com.anubhav.aakash.ui.radar.RadarViewModel
import com.anubhav.aakash.ui.settings.SettingsViewModel
import com.anubhav.aakash.ui.theme.AakashTheme

@OptIn(ExperimentalSharedTransitionApi::class)
val LocalSharedTransitionScope = staticCompositionLocalOf<androidx.compose.animation.SharedTransitionScope?> { null }

class MainActivity : ComponentActivity() {

    private lateinit var appContainer: AppContainer

    private val homeViewModel: HomeViewModel by viewModels {
        HomeViewModel.Factory(appContainer.weatherRepository)
    }

    private val settingsViewModel: SettingsViewModel by viewModels {
        SettingsViewModel.Factory(appContainer.weatherRepository)
    }

    private val radarViewModel: RadarViewModel by viewModels {
        RadarViewModel.Factory(appContainer.radarRepository, appContainer.weatherRepository)
    }

    @OptIn(ExperimentalSharedTransitionApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        appContainer = AppContainer(applicationContext)

        setContent {
            val isDarkMode by settingsViewModel.darkModeEnabled.collectAsState()

            AakashTheme(isDark = isDarkMode) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    val navController = rememberNavController()

                    SharedTransitionLayout(
                        modifier = Modifier.fillMaxSize()
                    ) {
                        AnimatedContent(
                            targetState = isDarkMode,
                            transitionSpec = {
                                (fadeIn(animationSpec = tween(500, easing = FastOutSlowInEasing)) +
                                 scaleIn(initialScale = 0.98f, animationSpec = tween(500, easing = FastOutSlowInEasing)))
                                    .togetherWith(
                                        fadeOut(animationSpec = tween(500, easing = FastOutSlowInEasing)) +
                                        scaleOut(targetScale = 1.02f, animationSpec = tween(500, easing = FastOutSlowInEasing))
                                    )
                            },
                            label = "theme_shared_transition",
                            modifier = Modifier.fillMaxSize()
                        ) { isDarkState ->
                            CompositionLocalProvider(
                                LocalSharedTransitionScope provides this@SharedTransitionLayout
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .sharedElement(
                                            rememberSharedContentState(key = "app_theme_root"),
                                            animatedVisibilityScope = this@AnimatedContent
                                        )
                                ) {
                                    AakashNavHost(
                                        navController = navController,
                                        homeViewModel = homeViewModel,
                                        settingsViewModel = settingsViewModel,
                                        radarViewModel = radarViewModel
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
