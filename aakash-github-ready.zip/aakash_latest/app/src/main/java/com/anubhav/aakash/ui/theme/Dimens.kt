package com.anubhav.aakash.ui.theme

import androidx.compose.ui.unit.dp

object Dimens {
    val spaceExtraSmall = 4.dp
    val spaceSmall = 8.dp
    val spaceMedium = 12.dp
    val spaceDefault = 16.dp
    val spaceLarge = 24.dp
    val spaceExtraLarge = 32.dp
    val spaceHuge = 48.dp

    val cardCornerRadius = 24.dp
    val pillCornerRadius = 50.dp
    val minTouchTarget = 48.dp

    val dockHeight = 64.dp
    val dockBottomPadding = 24.dp
}
