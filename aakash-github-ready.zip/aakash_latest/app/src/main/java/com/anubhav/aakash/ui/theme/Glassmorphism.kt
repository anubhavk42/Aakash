package com.anubhav.aakash.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.shape.RoundedCornerShape

fun Modifier.glassCard(
    cornerShape: Shape = RoundedCornerShape(24.dp),
    borderWidth: Dp = 1.dp,
    borderColor: Color = GlassBorder,
    opacity: Float = 0.15f
): Modifier = this
    .clip(cornerShape)
    .background(
        Brush.linearGradient(
            colors = listOf(
                Color.White.copy(alpha = opacity * 1.2f),
                Color.White.copy(alpha = opacity * 0.6f)
            )
        )
    )
    .border(
        width = borderWidth,
        brush = Brush.linearGradient(
            colors = listOf(
                borderColor,
                borderColor.copy(alpha = 0.1f)
            )
        ),
        shape = cornerShape
    )
