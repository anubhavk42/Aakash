package com.anubhav.aakash.data.repo

import com.anubhav.aakash.data.api.OpenMeteoService
import com.anubhav.aakash.data.api.RainViewerCatalog
import com.anubhav.aakash.data.api.RainViewerService

/**
  Tile URL builder (pure function, unit-testable)
 */
fun buildTileUrlTemplate(host: String, path: String): String {
    return "$host$path/512/{z}/{x}/{y}/2/1_1.png"
}

class RadarRepository(
    private val api: RainViewerService,
    private val openMeteoApi: OpenMeteoService? = null
) {
    private var cachedCatalog: RainViewerCatalog? = null
    private var lastFetchTimeMs: Long = 0L

    suspend fun fetchNowcast(lat: Double, lon: Double): Result<List<Double>> {
        val openMeteo = openMeteoApi ?: return Result.success(emptyList())
        return try {
            val response = openMeteo.getMinutelyPrecipitation(lat, lon)
            val list = response.minutely15?.precipitation ?: emptyList()
            Result.success(list.take(8))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun fetchFrames(forceRefresh: Boolean = false): Result<RainViewerCatalog> {
        val now = System.currentTimeMillis()
        if (!forceRefresh && cachedCatalog != null && (now - lastFetchTimeMs < 5 * 60 * 1000L)) {
            return Result.success(cachedCatalog!!)
        }

        return try {
            val catalog = api.getWeatherMaps()
            val sortedPast = catalog.radar.past.sortedBy { it.time }
            val sortedCatalog = catalog.copy(
                radar = catalog.radar.copy(past = sortedPast)
            )
            cachedCatalog = sortedCatalog
            lastFetchTimeMs = now
            Result.success(sortedCatalog)
        } catch (e: Exception) {
            if (cachedCatalog != null) {
                Result.success(cachedCatalog!!)
            } else {
                Result.failure(e)
            }
        }
    }
}
