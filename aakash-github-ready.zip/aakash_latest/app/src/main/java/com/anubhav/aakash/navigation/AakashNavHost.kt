package com.anubhav.aakash.navigation

import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import com.anubhav.aakash.ui.common.rememberHapticHelper
import com.anubhav.aakash.ui.forecast.ForecastScreen
import com.anubhav.aakash.ui.home.HomeScreen
import com.anubhav.aakash.ui.home.HomeViewModel
import com.anubhav.aakash.ui.navigation.BottomDock
import com.anubhav.aakash.ui.radar.RadarScreen
import com.anubhav.aakash.ui.radar.RadarViewModel
import com.anubhav.aakash.ui.settings.SettingsScreen
import com.anubhav.aakash.ui.settings.SettingsViewModel

@Composable
fun AakashNavHost(
    navController: NavHostController,
    homeViewModel: HomeViewModel,
    settingsViewModel: SettingsViewModel,
    radarViewModel: RadarViewModel,
    modifier: Modifier = Modifier
) {
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: "home"
    val hapticsEnabled by settingsViewModel.hapticsEnabled.collectAsState()
    val hapticHelper = rememberHapticHelper()

    Box(modifier = modifier.fillMaxSize()) {
        NavHost(
            navController = navController,
            startDestination = "home",
            enterTransition = { fadeIn() },
            exitTransition = { fadeOut() },
            popEnterTransition = { fadeIn() },
            popExitTransition = { fadeOut() },
            modifier = Modifier.fillMaxSize()
        ) {
            composable("home") {
                HomeScreen(
                    viewModel = homeViewModel,
                    onNavigateToForecast = { navController.navigate("forecast") }
                )
            }

            composable("forecast") {
                ForecastScreen(
                    homeViewModel = homeViewModel,
                    onBack = { navController.popBackStack() }
                )
            }

            composable("radar") {
                RadarScreen(
                    viewModel = radarViewModel,
                    hapticHelper = hapticHelper,
                    hapticsEnabled = hapticsEnabled
                )
            }

            composable("settings") {
                SettingsScreen(
                    viewModel = settingsViewModel,
                    onBack = { navController.popBackStack() }
                )
            }
        }

        // Floating Bottom Dock (hidden on settings route)
        if (currentRoute != "settings") {
            BottomDock(
                currentRoute = currentRoute,
                onNavigate = { route ->
                    navController.navigate(route) {
                        popUpTo("home") { saveState = true }
                        launchSingleTop = true
                        restoreState = true
                    }
                },
                hapticHelper = hapticHelper,
                hapticsEnabled = hapticsEnabled,
                modifier = Modifier.align(Alignment.BottomCenter)
            )
        }
    }
}
