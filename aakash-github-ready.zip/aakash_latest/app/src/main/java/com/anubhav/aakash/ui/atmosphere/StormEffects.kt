package com.anubhav.aakash.ui.atmosphere

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.anubhav.aakash.data.model.WeatherKind
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlin.random.Random

@Composable
fun StormEffects(
    modifier: Modifier = Modifier
) {
    val flashAlpha = remember { mutableFloatStateOf(0f) }

    LaunchedEffect(Unit) {
        while (isActive) {
            // Random interval 3 to 8 seconds
            val delayMs = 3000L + (Random.nextFloat() * 5000L).toLong()
            delay(delayMs)

            // First flash
            flashAlpha.floatValue = 0.5f
            delay(80)
            flashAlpha.floatValue = 0f
            delay(40)
            // Second flash
            flashAlpha.floatValue = 0.3f
            delay(60)
            flashAlpha.floatValue = 0f
        }
    }

    Box(modifier = modifier.fillMaxSize()) {
        // Rain layer at storm intensity
        RainParticles(
            kind = WeatherKind.STORM,
            modifier = Modifier.fillMaxSize()
        )

        // Lightning flash overlay
        if (flashAlpha.floatValue > 0f) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                drawRect(
                    color = Color.White.copy(alpha = flashAlpha.floatValue)
                )
            }
        }
    }
}
