package com.anubhav.aakash.ui.common

import kotlin.math.roundToInt

object UnitUtils {
    fun formatTemp(celsius: Double, unit: String): String {
        val converted = if (unit == "F") (celsius * 9.0 / 5.0) + 32.0 else celsius
        return "${converted.roundToInt()}°"
    }

    fun formatTempRaw(celsius: Double, unit: String): Int {
        val converted = if (unit == "F") (celsius * 9.0 / 5.0) + 32.0 else celsius
        return converted.roundToInt()
    }

    fun formatSpeed(kmh: Double, unit: String): String {
        return if (unit == "mph") {
            val mph = kmh * 0.621371
            "${mph.roundToInt()} mph"
        } else {
            "${kmh.roundToInt()} km/h"
        }
    }
}
