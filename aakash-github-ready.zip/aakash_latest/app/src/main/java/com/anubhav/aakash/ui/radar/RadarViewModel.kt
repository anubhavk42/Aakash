package com.anubhav.aakash.ui.radar

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.anubhav.aakash.data.api.RadarFrame
import com.anubhav.aakash.data.model.WeatherKind
import com.anubhav.aakash.data.repo.RadarRepository
import com.anubhav.aakash.data.repo.WeatherRepository
import com.anubhav.aakash.data.repo.buildTileUrlTemplate
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class RadarUiState(
    val isLoading: Boolean = true,
    val isError: Boolean = false,
    val errorMessage: String? = null,
    val host: String = "",
    val frames: List<RadarFrame> = emptyList(),
    val currentFrameIndex: Int = 0,
    val isPlaying: Boolean = false,
    val cityLat: Double = 28.6139,
    val cityLon: Double = 77.2090,
    val cityName: String = "New Delhi",
    val currentTemp: Int = 27,
    val weatherKind: WeatherKind = WeatherKind.CLEAR,
    val minutelyPrecipitation: List<Double> = emptyList(),
    val isLegendExpanded: Boolean = false
) {
    val currentFrame: RadarFrame?
        get() = frames.getOrNull(currentFrameIndex)

    val currentTileUrl: String?
        get() {
            val frame = currentFrame ?: return null
            if (host.isBlank() || frame.path.isBlank()) return null
            return buildTileUrlTemplate(host, frame.path)
        }
}

class RadarViewModel(
    private val radarRepository: RadarRepository,
    private val weatherRepository: WeatherRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(RadarUiState())
    val uiState: StateFlow<RadarUiState> = _uiState.asStateFlow()

    private var playbackJob: Job? = null

    init {
        loadCityLocation()
        loadCatalog()
    }

    fun loadCityLocation() {
        viewModelScope.launch {
            val city = weatherRepository.lastSelectedCityFlow.first()
            _uiState.update {
                it.copy(
                    cityLat = city.latitude,
                    cityLon = city.longitude,
                    cityName = city.name
                )
            }

            // Fetch weather for temperature and weather kind
            val weatherResult = weatherRepository.fetchWeather(city)
            weatherResult.onSuccess { weatherData ->
                _uiState.update { state ->
                    state.copy(
                        currentTemp = weatherData.current.temperature.toInt(),
                        weatherKind = weatherData.current.weatherKind
                    )
                }
            }

            // Fetch nowcast 15-min precipitation
            val nowcastResult = radarRepository.fetchNowcast(city.latitude, city.longitude)
            nowcastResult.onSuccess { list ->
                _uiState.update { state ->
                    state.copy(minutelyPrecipitation = list)
                }
            }
        }
    }

    fun toggleLegendExpanded() {
        _uiState.update { it.copy(isLegendExpanded = !it.isLegendExpanded) }
    }

    fun setLegendExpanded(expanded: Boolean) {
        _uiState.update { it.copy(isLegendExpanded = expanded) }
    }

    fun loadCatalog(forceRefresh: Boolean = false) {
        viewModelScope.launch {
            if (_uiState.value.frames.isEmpty()) {
                _uiState.update { it.copy(isLoading = true, isError = false, errorMessage = null) }
            }
            val result = radarRepository.fetchFrames(forceRefresh = forceRefresh)
            result.fold(
                onSuccess = { catalog ->
                    val frames = catalog.radar.past
                    val targetIndex = if (frames.isNotEmpty()) {
                        _uiState.value.currentFrameIndex.coerceIn(0, frames.size - 1)
                    } else 0

                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            host = catalog.host,
                            frames = frames,
                            currentFrameIndex = targetIndex,
                            isError = false,
                            errorMessage = null
                        )
                    }
                    if (frames.isNotEmpty() && !_uiState.value.isPlaying) {
                        play()
                    }
                },
                onFailure = { error ->
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            isError = it.frames.isEmpty(), // Only show full error card if no cached frames
                            errorMessage = error.localizedMessage ?: "Failed to fetch radar data"
                        )
                    }
                }
            )
        }
    }

    fun togglePlayPause() {
        if (_uiState.value.isPlaying) {
            pause()
        } else {
            play()
        }
    }

    fun play() {
        if (_uiState.value.frames.isEmpty()) return
        pause()
        _uiState.update { it.copy(isPlaying = true) }
        playbackJob = viewModelScope.launch {
            while (_uiState.value.isPlaying && _uiState.value.frames.isNotEmpty()) {
                delay(600L)
                _uiState.update { state ->
                    if (state.frames.isEmpty()) state
                    else {
                        val nextIdx = (state.currentFrameIndex + 1) % state.frames.size
                        state.copy(currentFrameIndex = nextIdx)
                    }
                }
            }
        }
    }

    fun pause() {
        playbackJob?.cancel()
        playbackJob = null
        _uiState.update { it.copy(isPlaying = false) }
    }

    fun seekToFrame(index: Int) {
        pause()
        val totalFrames = _uiState.value.frames.size
        if (totalFrames == 0) return

        val clampedIndex = index.coerceIn(0, totalFrames - 1)
        _uiState.update { it.copy(currentFrameIndex = clampedIndex) }

        // If pulled past or at the newest frame, refresh catalog
        if (index >= totalFrames - 1) {
            loadCatalog(forceRefresh = true)
        }
    }

    class Factory(
        private val radarRepository: RadarRepository,
        private val weatherRepository: WeatherRepository
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return RadarViewModel(radarRepository, weatherRepository) as T
        }
    }
}
