package com.anubhav.aakash.ui.atmosphere

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import com.anubhav.aakash.data.model.DayPhase
import com.anubhav.aakash.data.model.WeatherKind
import com.anubhav.aakash.ui.theme.*

@Composable
fun AtmosphereBackground(
    kind: WeatherKind,
    phase: DayPhase,
    animationsEnabled: Boolean = true,
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit = {}
) {
    // Determine 3-stop gradient colors based on phase and kind
    val duskMiddleColor = Color(0xFFB85C38)
    val dawnMiddleColor = Color(0xFFC77B58)

    val (targetTop, targetMid, targetBot) = when (phase) {
        DayPhase.DUSK -> {
            if (kind == WeatherKind.CLEAR || kind == WeatherKind.CLOUDY) {
                Triple(Color(0xFF2B1B4D), Color(0xFFB85C38), Color(0xFFE8A87C))
            } else {
                val (dayStart, dayEnd) = getDayGradient(kind)
                val blendedBot = lerp(dayEnd, duskMiddleColor, 0.25f)
                Triple(dayStart, lerp(dayStart, blendedBot, 0.5f), blendedBot)
            }
        }
        DayPhase.DAWN -> {
            if (kind == WeatherKind.CLEAR || kind == WeatherKind.CLOUDY) {
                Triple(Color(0xFF1B2A52), Color(0xFFC77B58), Color(0xFFF2C9A0))
            } else {
                val (dayStart, dayEnd) = getDayGradient(kind)
                val blendedBot = lerp(dayEnd, dawnMiddleColor, 0.25f)
                Triple(dayStart, lerp(dayStart, blendedBot, 0.5f), blendedBot)
            }
        }
        DayPhase.NIGHT -> {
            val (nightStart, nightEnd) = getNightGradient(kind)
            Triple(nightStart, lerp(nightStart, nightEnd, 0.5f), nightEnd)
        }
        DayPhase.DAY -> {
            val (dayStart, dayEnd) = getDayGradient(kind)
            Triple(dayStart, lerp(dayStart, dayEnd, 0.5f), dayEnd)
        }
    }

    // 1200ms smooth crossfade
    val topColor by animateColorAsState(
        targetValue = targetTop,
        animationSpec = tween(1200),
        label = "gradient_top"
    )
    val midColor by animateColorAsState(
        targetValue = targetMid,
        animationSpec = tween(1200),
        label = "gradient_mid"
    )
    val botColor by animateColorAsState(
        targetValue = targetBot,
        animationSpec = tween(1200),
        label = "gradient_bot"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(topColor, midColor, botColor)
                )
            )
    ) {
        // Particle & Atmosphere layer behind content
        if (animationsEnabled) {
            when (phase) {
                DayPhase.DAY -> {
                    when (kind) {
                        WeatherKind.CLEAR -> SunAndRays(isLowSun = false)
                        WeatherKind.CLOUDY -> CloudParticles()
                        WeatherKind.OVERCAST -> OvercastBands()
                        WeatherKind.DRIZZLE -> RainParticles(kind = WeatherKind.DRIZZLE)
                        WeatherKind.RAIN -> RainParticles(kind = WeatherKind.RAIN)
                        WeatherKind.STORM -> StormEffects()
                        WeatherKind.SNOW -> SnowParticles()
                        WeatherKind.FOG -> FogBands()
                    }
                }
                DayPhase.NIGHT -> {
                    when (kind) {
                        WeatherKind.CLEAR -> MoonAndStars()
                        WeatherKind.CLOUDY -> MoonAndStars()
                        WeatherKind.OVERCAST -> OvercastBands()
                        WeatherKind.DRIZZLE -> RainParticles(kind = WeatherKind.DRIZZLE)
                        WeatherKind.RAIN -> RainParticles(kind = WeatherKind.RAIN)
                        WeatherKind.STORM -> StormEffects()
                        WeatherKind.SNOW -> SnowParticles()
                        WeatherKind.FOG -> FogBands()
                    }
                }
                DayPhase.DUSK, DayPhase.DAWN -> {
                    when (kind) {
                        WeatherKind.CLEAR -> SunAndRays(isLowSun = true)
                        WeatherKind.CLOUDY -> CloudParticles()
                        WeatherKind.OVERCAST -> OvercastBands()
                        WeatherKind.DRIZZLE -> RainParticles(kind = WeatherKind.DRIZZLE)
                        WeatherKind.RAIN -> RainParticles(kind = WeatherKind.RAIN)
                        WeatherKind.STORM -> StormEffects()
                        WeatherKind.SNOW -> SnowParticles()
                        WeatherKind.FOG -> FogBands()
                    }
                }
            }
        }

        // Foreground content overlay
        content()
    }
}

private fun getDayGradient(kind: WeatherKind): Pair<Color, Color> {
    return when (kind) {
        WeatherKind.CLEAR -> Pair(ClearDayStart, ClearDayEnd)
        WeatherKind.CLOUDY -> Pair(CloudyDayStart, CloudyDayEnd)
        WeatherKind.OVERCAST -> Pair(OvercastDayStart, OvercastDayEnd)
        WeatherKind.DRIZZLE -> Pair(DrizzleStart, DrizzleEnd)
        WeatherKind.RAIN -> Pair(RainStart, RainEnd)
        WeatherKind.STORM -> Pair(StormStart, StormEnd)
        WeatherKind.SNOW -> Pair(SnowStart, SnowEnd)
        WeatherKind.FOG -> Pair(FogStart, FogEnd)
    }
}

private fun getNightGradient(kind: WeatherKind): Pair<Color, Color> {
    return when (kind) {
        WeatherKind.CLEAR -> Pair(ClearNightStart, ClearNightEnd)
        WeatherKind.OVERCAST -> Pair(OvercastNightStart, OvercastNightEnd)
        WeatherKind.CLOUDY -> Pair(ClearNightStart, ClearNightEnd)
        WeatherKind.DRIZZLE -> Pair(DrizzleStart, DrizzleEnd)
        WeatherKind.RAIN -> Pair(RainStart, RainEnd)
        WeatherKind.STORM -> Pair(StormStart, StormEnd)
        WeatherKind.SNOW -> Pair(SnowStart, SnowEnd)
        WeatherKind.FOG -> Pair(FogStart, FogEnd)
    }
}
