package com.anubhav.aakash.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Animation
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.anubhav.aakash.ui.common.rememberHapticHelper
import com.anubhav.aakash.ui.theme.CyanAccent
import com.anubhav.aakash.ui.theme.GlassBackground
import com.anubhav.aakash.ui.theme.GlassBorder
import com.anubhav.aakash.ui.theme.IndigoBaseDark
import com.anubhav.aakash.ui.theme.TextPrimary
import com.anubhav.aakash.ui.theme.TextSecondary
import com.anubhav.aakash.ui.theme.glassCard

@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val tempUnit by viewModel.tempUnit.collectAsState()
    val speedUnit by viewModel.speedUnit.collectAsState()
    val animationsEnabled by viewModel.animationsEnabled.collectAsState()
    val hapticsEnabled by viewModel.hapticsEnabled.collectAsState()
    val darkModeEnabled by viewModel.darkModeEnabled.collectAsState()

    val hapticHelper = rememberHapticHelper()
    val scrollState = rememberScrollState()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(IndigoBaseDark)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .verticalScroll(scrollState)
                .padding(bottom = 40.dp)
        ) {
            // Header Row with Back Chevron
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = {
                        hapticHelper.triggerClick(hapticsEnabled)
                        onBack()
                    },
                    modifier = Modifier.testTag("settings_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = TextPrimary
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Text(
                    text = "Settings",
                    style = MaterialTheme.typography.titleLarge,
                    color = TextPrimary
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Units Section
            SectionHeader(title = "UNITS")

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
                    .glassCard(RoundedCornerShape(24.dp))
                    .padding(16.dp)
            ) {
                // Temperature Unit Segmented Control
                SegmentedControlRow(
                    icon = Icons.Filled.Thermostat,
                    title = "Temperature",
                    options = listOf("Celsius (°C)" to "C", "Fahrenheit (°F)" to "F"),
                    selectedOption = tempUnit,
                    onSelect = { option ->
                        hapticHelper.triggerClick(hapticsEnabled)
                        viewModel.setTempUnit(option)
                    },
                    testTagPrefix = "temp_unit"
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Speed Unit Segmented Control
                SegmentedControlRow(
                    icon = Icons.Filled.Speed,
                    title = "Wind Speed",
                    options = listOf("km/h" to "kmh", "mph" to "mph"),
                    selectedOption = speedUnit,
                    onSelect = { option ->
                        hapticHelper.triggerClick(hapticsEnabled)
                        viewModel.setSpeedUnit(option)
                    },
                    testTagPrefix = "speed_unit"
                )
            }

            Spacer(modifier = Modifier.height(28.dp))

            // Experience Section
            SectionHeader(title = "EXPERIENCE")

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
                    .glassCard(RoundedCornerShape(24.dp))
                    .padding(16.dp)
            ) {
                // Theme Toggle
                SwitchSettingRow(
                    icon = if (darkModeEnabled) Icons.Filled.DarkMode else Icons.Filled.LightMode,
                    title = "Dark Theme",
                    subtitle = if (darkModeEnabled) "Dark mode enabled" else "Light mode enabled",
                    checked = darkModeEnabled,
                    onCheckedChange = { enabled ->
                        hapticHelper.triggerClick(hapticsEnabled)
                        viewModel.setDarkModeEnabled(enabled)
                    },
                    testTag = "theme_switch"
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Weather Animations Toggle
                SwitchSettingRow(
                    icon = Icons.Filled.Animation,
                    title = "Weather Animations",
                    subtitle = "Dynamic particles & atmospheric effects",
                    checked = animationsEnabled,
                    onCheckedChange = { enabled ->
                        hapticHelper.triggerClick(hapticsEnabled)
                        viewModel.setAnimationsEnabled(enabled)
                    },
                    testTag = "animations_switch"
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Haptic Feedback Toggle
                SwitchSettingRow(
                    icon = Icons.Filled.Vibration,
                    title = "Haptic Feedback",
                    subtitle = "Tactile sensations on interactions",
                    checked = hapticsEnabled,
                    onCheckedChange = { enabled ->
                        hapticHelper.triggerClick(enabled) // test new state
                        viewModel.setHapticsEnabled(enabled)
                    },
                    testTag = "haptics_switch"
                )
            }

            Spacer(modifier = Modifier.height(40.dp))

            // About Footer
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = Icons.Filled.Info,
                    contentDescription = "About",
                    tint = CyanAccent,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Aakash v1.0",
                    style = MaterialTheme.typography.titleMedium,
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Crafted with Open-Meteo Weather Engine",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary
                )
            }
        }
    }
}

@Composable
private fun SectionHeader(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.labelSmall,
        color = TextSecondary,
        modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp)
    )
}

@Composable
private fun SegmentedControlRow(
    icon: ImageVector,
    title: String,
    options: List<Pair<String, String>>,
    selectedOption: String,
    onSelect: (String) -> Unit,
    testTagPrefix: String
) {
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(imageVector = icon, contentDescription = title, tint = CyanAccent, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(text = title, style = MaterialTheme.typography.titleMedium, color = TextPrimary)
        }
        Spacer(modifier = Modifier.height(10.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(CircleShape)
                .background(GlassBackground)
                .border(1.dp, GlassBorder, CircleShape)
                .padding(4.dp)
        ) {
            options.forEach { (label, value) ->
                val isSelected = selectedOption == value
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .testTag("${testTagPrefix}_${value}")
                        .clip(CircleShape)
                        .background(if (isSelected) CyanAccent else Color.Transparent)
                        .clickable { onSelect(value) }
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = label,
                        color = if (isSelected) Color.Black else TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }
        }
    }
}

@Composable
private fun SwitchSettingRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    testTag: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            modifier = Modifier.weight(1f),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(imageVector = icon, contentDescription = title, tint = CyanAccent, modifier = Modifier.size(22.dp))
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(text = title, style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                Text(text = subtitle, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            }
        }

        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.Black,
                checkedTrackColor = CyanAccent,
                uncheckedThumbColor = TextSecondary,
                uncheckedTrackColor = GlassBackground
            ),
            modifier = Modifier.testTag(testTag)
        )
    }
}
