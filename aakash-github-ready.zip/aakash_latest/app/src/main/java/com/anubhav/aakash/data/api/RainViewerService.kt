package com.anubhav.aakash.data.api

import com.google.gson.annotations.SerializedName
import retrofit2.http.GET

data class RainViewerCatalog(
    @SerializedName("host") val host: String = "",
    @SerializedName("radar") val radar: RadarFrames = RadarFrames()
)

data class RadarFrames(
    @SerializedName("past") val past: List<RadarFrame> = emptyList()
)

data class RadarFrame(
    @SerializedName("time") val time: Long = 0L,
    @SerializedName("path") val path: String = ""
)

interface RainViewerService {
    @GET("public/weather-maps.json")
    suspend fun getWeatherMaps(): RainViewerCatalog
}
