package com.anubhav.aakash.data.model

import com.google.gson.annotations.SerializedName

// WeatherKind Enum with WMO mapping
enum class WeatherKind(val description: String) {
    CLEAR("Clear Sky"),
    CLOUDY("Cloudy"),
    OVERCAST("Overcast"),
    DRIZZLE("Drizzle"),
    RAIN("Rain"),
    STORM("Thunderstorm"),
    SNOW("Snowfall"),
    FOG("Foggy");

    companion object {
        fun fromWmoCode(code: Int): WeatherKind {
            return when (code) {
                0, 1 -> CLEAR
                2 -> CLOUDY
                3 -> OVERCAST
                45, 48 -> FOG
                51, 53, 55, 56, 57 -> DRIZZLE
                61, 63, 65, 66, 67, 80, 81, 82 -> RAIN
                71, 73, 75, 77, 85, 86 -> SNOW
                95, 96, 99 -> STORM
                else -> CLEAR
            }
        }
    }
}

// Open-Meteo Forecast DTOs
data class OpenMeteoResponse(
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val current: CurrentDataDto? = null,
    val hourly: HourlyDataDto? = null,
    val daily: DailyDataDto? = null
)

data class CurrentDataDto(
    @SerializedName("temperature_2m") val temperature2m: Double = 0.0,
    @SerializedName("relative_humidity_2m") val relativeHumidity2m: Int = 0,
    @SerializedName("apparent_temperature") val apparentTemperature: Double = 0.0,
    @SerializedName("is_day") val isDay: Int = 1,
    @SerializedName("precipitation") val precipitation: Double = 0.0,
    @SerializedName("weather_code") val weatherCode: Int = 0,
    @SerializedName("surface_pressure") val surfacePressure: Double = 1013.25,
    @SerializedName("wind_speed_10m") val windSpeed10m: Double = 0.0,
    @SerializedName("uv_index") val uvIndex: Double? = 0.0
)

data class HourlyDataDto(
    val time: List<Long> = emptyList(),
    @SerializedName("temperature_2m") val temperature2m: List<Double> = emptyList(),
    @SerializedName("weather_code") val weatherCode: List<Int> = emptyList(),
    @SerializedName("precipitation_probability") val precipitationProbability: List<Int>? = emptyList()
)

data class DailyDataDto(
    val time: List<Long> = emptyList(),
    @SerializedName("weather_code") val weatherCode: List<Int> = emptyList(),
    @SerializedName("temperature_2m_max") val temperature2mMax: List<Double> = emptyList(),
    @SerializedName("temperature_2m_min") val temperature2mMin: List<Double> = emptyList(),
    @SerializedName("precipitation_probability_max") val precipitationProbabilityMax: List<Int>? = emptyList(),
    val sunrise: List<Long>? = emptyList(),
    val sunset: List<Long>? = emptyList()
)

// Open-Meteo Geocoding DTOs
data class GeocodingResponse(
    val results: List<GeoPlaceDto>? = null
)

data class GeoPlaceDto(
    val id: Long = 0L,
    val name: String = "",
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val country: String? = null,
    val admin1: String? = null,
    @SerializedName("country_code") val countryCode: String? = null
)

// Domain Models
data class GeoPlace(
    val id: Long,
    val name: String,
    val latitude: Double,
    val longitude: Double,
    val country: String,
    val admin1: String
)

data class CurrentWeather(
    val temperature: Double,
    val feelsLike: Double,
    val humidity: Int,
    val windSpeed: Double,
    val pressure: Double,
    val uvIndex: Double,
    val precipitation: Double,
    val weatherKind: WeatherKind,
    val isNight: Boolean,
    val weatherDescription: String
)

data class HourlyItem(
    val time: String,
    val temp: Double,
    val weatherKind: WeatherKind,
    val precipProb: Int,
    val isNow: Boolean
)

data class DailyItem(
    val date: String,
    val dayName: String,
    val weatherKind: WeatherKind,
    val tempMin: Double,
    val tempMax: Double,
    val precipProb: Int,
    val sunrise: String,
    val sunset: String,
    val humidity: Int = 60
)

// Open-Meteo Air Quality DTOs
data class AirQualityResponse(
    val current: AirQualityDto? = null
)

data class AirQualityDto(
    @SerializedName("us_aqi") val usAqi: Int? = null,
    @SerializedName("pm2_5") val pm25: Double? = null,
    @SerializedName("pm10") val pm10: Double? = null
)

data class AirQualityData(
    val usAqi: Int,
    val pm25: Double? = null,
    val pm10: Double? = null
)

// Open-Meteo Minutely 15 DTOs
data class Minutely15Response(
    @SerializedName("minutely_15") val minutely15: Minutely15DataDto? = null
)

data class Minutely15DataDto(
    val time: List<Long> = emptyList(),
    val precipitation: List<Double> = emptyList()
)

enum class DayPhase { DAY, DUSK, NIGHT, DAWN }

fun computeDayPhase(
    nowMillis: Long,
    sunriseMillis: Long?,
    sunsetMillis: Long?,
    fallbackIsNight: Boolean = false
): DayPhase {
    if (sunriseMillis == null || sunsetMillis == null || sunriseMillis <= 0L || sunsetMillis <= 0L) {
        return if (fallbackIsNight) DayPhase.NIGHT else DayPhase.DAY
    }

    val offset = 40 * 60 * 1000L // 40 minutes

    val dawnStart = sunriseMillis - offset
    val dawnEnd = sunriseMillis + offset

    val duskStart = sunsetMillis - offset
    val duskEnd = sunsetMillis + offset

    return when (nowMillis) {
        in dawnStart..dawnEnd -> DayPhase.DAWN
        in duskStart..duskEnd -> DayPhase.DUSK
        in (dawnEnd + 1) until duskStart -> DayPhase.DAY
        else -> DayPhase.NIGHT
    }
}

data class WeatherData(
    val city: GeoPlace,
    val current: CurrentWeather,
    val hourly: List<HourlyItem>,
    val daily: List<DailyItem>,
    val airQuality: AirQualityData? = null,
    val lastUpdatedEpoch: Long = System.currentTimeMillis(),
    val sunriseEpochMillis: Long? = null,
    val sunsetEpochMillis: Long? = null
)
