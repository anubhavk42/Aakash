package com.anubhav.aakash.ui.atmosphere

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.isActive
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

private class Star(
    var x: Float = 0f,
    var y: Float = 0f,
    var radius: Float = 0f,
    var baseAlpha: Float = 0.5f,
    var speed: Float = 1f,
    var phase: Float = 0f
)

@Composable
fun SunAndRays(
    modifier: Modifier = Modifier,
    isLowSun: Boolean = false
) {
    val infiniteTransition = rememberInfiniteTransition(label = "sun_rotation")
    val rotation = infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(60000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    Canvas(modifier = modifier.fillMaxSize()) {
        val centerX = size.width * 0.75f
        val centerY = if (isLowSun) size.height * 0.78f else size.height * 0.22f
        val sunRadius = if (isLowSun) 58.dp.toPx() else 45.dp.toPx()

        val glowColors = if (isLowSun) {
            listOf(
                Color(0xFFFFB347).copy(alpha = 0.55f),
                Color(0xFFFF8A65).copy(alpha = 0.25f),
                Color.Transparent
            )
        } else {
            listOf(
                Color(0xFFFFEE58).copy(alpha = 0.45f),
                Color(0xFFFFA726).copy(alpha = 0.20f),
                Color.Transparent
            )
        }

        val coreColors = if (isLowSun) {
            listOf(
                Color(0xFFFFE0B2),
                Color(0xFFFFB347)
            )
        } else {
            listOf(
                Color(0xFFFFF9C4),
                Color(0xFFFFD54F)
            )
        }

        val rayAlphaMultiplier = if (isLowSun) 0.40f else 1.0f

        // Outer glow
        drawCircle(
            brush = Brush.radialGradient(
                colors = glowColors,
                center = Offset(centerX, centerY),
                radius = sunRadius * 2.8f
            ),
            radius = sunRadius * 2.8f,
            center = Offset(centerX, centerY)
        )

        // Core sun
        drawCircle(
            brush = Brush.radialGradient(
                colors = coreColors,
                center = Offset(centerX, centerY),
                radius = sunRadius
            ),
            radius = sunRadius,
            center = Offset(centerX, centerY)
        )

        // 12 rotating rays
        rotate(degrees = rotation.value, pivot = Offset(centerX, centerY)) {
            val rayLength = 32.dp.toPx()
            val rayStart = sunRadius + 8.dp.toPx()
            for (i in 0 until 12) {
                val angle = Math.toRadians((i * 30).toDouble())
                val startX = centerX + (rayStart * cos(angle)).toFloat()
                val startY = centerY + (rayStart * sin(angle)).toFloat()
                val endX = centerX + ((rayStart + rayLength) * cos(angle)).toFloat()
                val endY = centerY + ((rayStart + rayLength) * sin(angle)).toFloat()

                drawLine(
                    color = Color(0xFFFFECB3).copy(alpha = 0.6f * rayAlphaMultiplier),
                    start = Offset(startX, startY),
                    end = Offset(endX, endY),
                    strokeWidth = 3.dp.toPx(),
                    cap = StrokeCap.Round
                )
            }
        }
    }
}

@Composable
fun MoonAndStars(modifier: Modifier = Modifier) {
    val density = LocalDensity.current
    val starCount = 20
    val stars = remember { Array(starCount) { Star() } }
    val isInitialized = remember { BooleanArray(1) { false } }

    val infiniteTransition = rememberInfiniteTransition(label = "stars_twinkle")
    val pulse = infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(2500, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    Canvas(modifier = modifier.fillMaxSize()) {
        val width = size.width
        val height = size.height

        if (!isInitialized[0] && width > 0 && height > 0) {
            for (i in 0 until starCount) {
                stars[i].x = Random.nextFloat() * width
                stars[i].y = Random.nextFloat() * (height * 0.5f)
                stars[i].radius = with(density) { (1.5f + Random.nextFloat() * 2f).dp.toPx() }
                stars[i].baseAlpha = 0.2f + Random.nextFloat() * 0.6f
                stars[i].phase = Random.nextFloat() * 6.28f
            }
            isInitialized[0] = true
        }

        // Draw Twinkling Stars
        for (i in 0 until starCount) {
            val star = stars[i]
            val alpha = (star.baseAlpha * pulse.value).coerceIn(0.1f, 1.0f)
            drawCircle(
                color = Color.White.copy(alpha = alpha),
                radius = star.radius,
                center = Offset(star.x, star.y)
            )
        }

        // Crescent Moon
        val moonX = width * 0.75f
        val moonY = height * 0.20f
        val moonRadius = 38.dp.toPx()

        // Outer glow
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    Color(0xFFE0E0E0).copy(alpha = 0.30f),
                    Color.Transparent
                ),
                center = Offset(moonX, moonY),
                radius = moonRadius * 2.2f
            ),
            radius = moonRadius * 2.2f,
            center = Offset(moonX, moonY)
        )

        // Moon body with shadow cut for crescent
        drawCircle(
            color = Color(0xFFFFFDE7),
            radius = moonRadius,
            center = Offset(moonX, moonY)
        )
        // Shadow cut out
        drawCircle(
            color = Color(0xFF090A0F),
            radius = moonRadius * 0.9f,
            center = Offset(moonX - moonRadius * 0.45f, moonY - moonRadius * 0.25f)
        )
    }
}

@Composable
fun FogBands(modifier: Modifier = Modifier) {
    val frameState = remember { androidx.compose.runtime.mutableLongStateOf(0L) }
    val offsets = remember { floatArrayOf(0f, 0f, 0f) }

    LaunchedEffect(Unit) {
        var lastNanos = 0L
        while (isActive) {
            withFrameNanos { nanos ->
                if (lastNanos != 0L) {
                    val dt = ((nanos - lastNanos) / 1_000_000_000f).coerceAtMost(0.05f)
                    frameState.longValue = nanos
                    offsets[0] = (offsets[0] + dt * 25f) % 2000f
                    offsets[1] = (offsets[1] - dt * 35f) % 2000f
                    offsets[2] = (offsets[2] + dt * 18f) % 2000f
                }
                lastNanos = nanos
            }
        }
    }

    Canvas(modifier = modifier.fillMaxSize()) {
        @Suppress("UNUSED_VARIABLE")
        val dummy = frameState.longValue
        val w = size.width
        val h = size.height

        val yPositions = floatArrayOf(h * 0.25f, h * 0.45f, h * 0.65f)
        val bandHeights = floatArrayOf(120.dp.toPx(), 160.dp.toPx(), 140.dp.toPx())
        val alphas = floatArrayOf(0.18f, 0.25f, 0.20f)

        for (i in 0..2) {
            val y = yPositions[i]
            val bh = bandHeights[i]
            val shift = offsets[i]

            drawRect(
                brush = Brush.horizontalGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.05f),
                        Color.White.copy(alpha = alphas[i]),
                        Color.White.copy(alpha = alphas[i] * 0.7f),
                        Color.White.copy(alpha = 0.05f)
                    ),
                    startX = -w + (shift % w),
                    endX = w + (shift % w)
                ),
                topLeft = Offset(0f, y - bh / 2),
                size = Size(w, bh)
            )
        }
    }
}

@Composable
fun CloudParticles(modifier: Modifier = Modifier) {
    val frameState = remember { androidx.compose.runtime.mutableLongStateOf(0L) }
    val cloudX = remember { floatArrayOf(0f, 300f, 600f) }

    LaunchedEffect(Unit) {
        var lastNanos = 0L
        while (isActive) {
            withFrameNanos { nanos ->
                if (lastNanos != 0L) {
                    val dt = ((nanos - lastNanos) / 1_000_000_000f).coerceAtMost(0.05f)
                    frameState.longValue = nanos
                    cloudX[0] = (cloudX[0] + dt * 15f)
                    cloudX[1] = (cloudX[1] + dt * 22f)
                    cloudX[2] = (cloudX[2] + dt * 12f)
                }
                lastNanos = nanos
            }
        }
    }

    Canvas(modifier = modifier.fillMaxSize()) {
        @Suppress("UNUSED_VARIABLE")
        val dummy = frameState.longValue
        val w = size.width
        val h = size.height

        val cloudY = floatArrayOf(h * 0.15f, h * 0.28f, h * 0.40f)
        val cloudRadius = floatArrayOf(70.dp.toPx(), 90.dp.toPx(), 65.dp.toPx())

        for (i in 0..2) {
            val cx = (cloudX[i] % (w + 400f)) - 200f
            val cy = cloudY[i]
            val r = cloudRadius[i]

            // Draw fluffy cloud with overlapping circles
            val cloudColor = Color.White.copy(alpha = 0.16f)
            drawCircle(color = cloudColor, radius = r, center = Offset(cx, cy))
            drawCircle(color = cloudColor, radius = r * 0.75f, center = Offset(cx - r * 0.6f, cy + r * 0.2f))
            drawCircle(color = cloudColor, radius = r * 0.8f, center = Offset(cx + r * 0.6f, cy + r * 0.15f))
            drawCircle(color = cloudColor, radius = r * 0.65f, center = Offset(cx + r * 1.1f, cy + r * 0.3f))
        }
    }
}

@Composable
fun OvercastBands(modifier: Modifier = Modifier) {
    val frameState = remember { androidx.compose.runtime.mutableLongStateOf(0L) }
    val offsets = remember { floatArrayOf(0f, 0f, 0f) }

    LaunchedEffect(Unit) {
        var lastNanos = 0L
        while (isActive) {
            withFrameNanos { nanos ->
                if (lastNanos != 0L) {
                    val dt = ((nanos - lastNanos) / 1_000_000_000f).coerceAtMost(0.05f)
                    frameState.longValue = nanos
                    offsets[0] = (offsets[0] + dt * 10f) % 2000f
                    offsets[1] = (offsets[1] - dt * 14f) % 2000f
                    offsets[2] = (offsets[2] + dt * 8f) % 2000f
                }
                lastNanos = nanos
            }
        }
    }

    Canvas(modifier = modifier.fillMaxSize()) {
        @Suppress("UNUSED_VARIABLE")
        val dummy = frameState.longValue
        val w = size.width
        val h = size.height

        val yPositions = floatArrayOf(h * 0.20f, h * 0.40f, h * 0.60f)
        val bandHeights = floatArrayOf(150.dp.toPx(), 200.dp.toPx(), 180.dp.toPx())
        val alphas = floatArrayOf(0.38f, 0.48f, 0.42f)

        for (i in 0..2) {
            val y = yPositions[i]
            val bh = bandHeights[i]
            val shift = offsets[i]

            drawRect(
                brush = Brush.horizontalGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.08f),
                        Color.White.copy(alpha = alphas[i]),
                        Color.White.copy(alpha = alphas[i] * 0.75f),
                        Color.White.copy(alpha = 0.08f)
                    ),
                    startX = -w + (shift % w),
                    endX = w + (shift % w)
                ),
                topLeft = Offset(0f, y - bh / 2),
                size = Size(w, bh)
            )
        }
    }
}
