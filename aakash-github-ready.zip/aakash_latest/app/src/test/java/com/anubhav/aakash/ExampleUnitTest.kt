package com.anubhav.aakash

import com.anubhav.aakash.data.repo.buildTileUrlTemplate
import org.junit.Assert.*
import org.junit.Test

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * See [testing documentation](http://d.android.com/tools/testing).
 */
class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun buildTileUrlTemplate_isCorrect() {
    val host = "https://tilecache.rainviewer.com"
    val path = "/v2/radar/1234567890"
    val url = buildTileUrlTemplate(host, path)
    assertEquals("https://tilecache.rainviewer.com/v2/radar/1234567890/512/{z}/{x}/{y}/2/1_1.png", url)
  }
}
